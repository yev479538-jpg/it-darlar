// ============================================================================
// FASHION QUEEN — ADULT HAUTE COUTURE SKETCHBOOK & STUDIO ENGINE
// ============================================================================

const state = {
  playerName: "Zara",
  stars: 250,
  score: 98540,
  combo: 25,
  followersCount: 128,
  followingCount: 2,
  activeView: "home",
  activeRailTool: "clothes",
  activeCategory: "dresses",
  activeMannequinId: "female_pose_1",
  showGuides: true,
  mirrorPose: false,
  editingPortfolioId: null,
  stickerPosition: "top-right",

  studio: {
    dressName: "Kundalik Ko'k Denim Ko'ylak",
    color: "#c99b94",
    hairColor: "#2b221e",
    fabricId: "fabric_silk_pink",
    bgStyle: "notebook_2024",
    customText: "",
    equipped: {
      faces: "face_editorial_2",
      hair: "hair_long_waves",
      materials: null,
      dresses: "dress_exact_1",
      tops: null,
      trousers: null,
      bottom_details: null,
      bags: null,
      belt: null,
      shoes: "shoe_col_1",
      stickers: null
    },
    history: [],
    redoStack: []
  },

  ownedMarketIds: [
    "fabric_silk_pink",
    "fabric_cream_satin",
    "tool_tape",
    "bag_birkin_gold"
  ],

  unlockedBadges: [
    "first_competition",
    "event_warrior",
    "first_sketch",
    "prolific_designer",
    "community_debut"
  ],

  portfolio: [],
  posts: [],

  followActivityLog: [
    { id: "act_1", actor: "Tia Moghrabi", target: "Zara", type: "followed_you", time: "2m ago", actorId: "comp_1" },
    { id: "act_2", actor: "MAR (NO AI)", target: "Zara", type: "followed_you", time: "5m ago", actorId: "comp_2" },
    { id: "act_3", actor: "Zara", target: "Tia Moghrabi", type: "you_followed", time: "8m ago", actorId: "comp_1" },
    { id: "act_4", actor: "LHETYBOOK", target: "MAR (NO AI)", type: "other_follow", time: "12m ago", actorId: "comp_3" },
    { id: "act_5", actor: "ALISHIA", target: "Zara", type: "followed_you", time: "15m ago", actorId: "comp_5" },
    { id: "act_6", actor: "BEC HANSEN", target: "Tia Moghrabi", type: "other_follow", time: "20m ago", actorId: "comp_4" }
  ],

  quizIndex: 0,
  unicornTipIndex: 0
};

// ============================================================================
// 1. EXACT EXTRACTED FEMALE FASHION MANNEQUINS (Copied directly from user's image!)
// ============================================================================
const MANNEQUINS = [
  {
    id: "female_pose_1",
    imgSrc: "assets/mannequin_pose_1.png",
    name: "Female — Pose I (Qo'li Belida)",
    subtitle: "Siz yuborgan rasmdan aynan nusxalangan 1-ayollar manekeni"
  },
  {
    id: "female_pose_2",
    imgSrc: "assets/mannequin_pose_2.png",
    name: "Female — Pose II (Podium Yurishi)",
    subtitle: "Siz yuborgan rasmdan aynan nusxalangan 2-ayollar manekeni"
  },
  {
    id: "female_pose_3",
    imgSrc: "assets/mannequin_pose_3.png",
    name: "Female — Pose III (O'ng Qo'li Belida)",
    subtitle: "Siz yuborgan rasmdan nusxalangan 3-ayollar manekeni (oynali)"
  }
];

// ============================================================================
// 1B. NOTEBOOK SKETCH PRESETS ("Ko'ylak Dizayni 2024" — 4 exact notebook looks)
// ============================================================================
const NOTEBOOK_SKETCH_PRESETS = [
  {
    id: "nb_yellow",
    title: "1. Sariq Puff-Yengli Ipak Ko'ylak",
    subtitle: "Daftardagi 1-eskiz • Ipak mato & akvarel",
    mannequinId: "female_pose_1",
    color: "#f2c230",
    hairColor: "#241c18",
    bgStyle: "notebook_2024",
    equipped: {
      faces: "face_editorial_1",
      hair: "hair_long_waves",
      materials: "mat_notebook_yellow_silk",
      dresses: "dress_notebook_yellow",
      belt: null,
      bags: null,
      shoes: "heels_classic"
    }
  },
  {
    id: "nb_floral_maxi",
    title: "2. Gulli Uzun Shifon Oqshom Ko'ylagi",
    subtitle: "Daftardagi 2-eskiz • Gulli shifon mato",
    mannequinId: "female_pose_2",
    color: "#f5eae2",
    hairColor: "#2d1f18",
    bgStyle: "notebook_2024",
    equipped: {
      faces: "face_editorial_2",
      hair: "hair_couture_bun",
      materials: "mat_notebook_floral",
      dresses: "dress_notebook_floral_maxi",
      belt: null,
      bags: null,
      shoes: "heels_strappy"
    }
  },
  {
    id: "nb_iceblue",
    title: "3. Havorang Yelkasi Ochiq Plisseli Ko'ylak",
    subtitle: "Daftardagi 3-eskiz • Plisseli shifon & kamar",
    mannequinId: "female_pose_1",
    color: "#b7cde2",
    hairColor: "#523422",
    bgStyle: "notebook_2024",
    equipped: {
      faces: "face_editorial_1",
      hair: "hair_long_waves",
      materials: "mat_notebook_ice_pleat",
      dresses: "dress_notebook_iceblue",
      belt: "belt_ribbon",
      bags: null,
      shoes: "heels_classic"
    }
  },
  {
    id: "nb_blush_floral",
    title: "4. Shaftolirang Gulli Kokteyl Ko'ylagi",
    subtitle: "Daftardagi 4-eskiz • Kashtali gulli to'r",
    mannequinId: "female_pose_3",
    color: "#ecc0b2",
    hairColor: "#362419",
    bgStyle: "notebook_2024",
    equipped: {
      faces: "face_editorial_3",
      hair: "hair_couture_bun",
      materials: "mat_notebook_blush_emb",
      dresses: "dress_notebook_blush_floral",
      belt: null,
      bags: null,
      shoes: "heels_strappy"
    }
  }
];

// ============================================================================
// 2. STUDIO CATEGORIES
// ============================================================================
const STUDIO_CATEGORIES = [
  { id: "dresses", label: "Dresses" },
  { id: "materials", label: "Yaltiroq Materiallar (Shimmer)" },
  { id: "faces", label: "Faces" },
  { id: "hair", label: "Hairstyles" },
  { id: "bags", label: "Bags" },
  { id: "tops", label: "Tops & Bodices" },
  { id: "trousers", label: "Trousers" },
  { id: "bottom_details", label: "Skirts & Details" },
  { id: "belt", label: "Belts" },
  { id: "shoes", label: "Footwear" },
  { id: "stickers", label: "Stickers" }
];

const GARMENT_ITEMS = {
  materials: [
    { id: "mat_notebook_floral", name: "Daftardagi Gulli Shifon (Floral)", color: "#f5eae2", shimmer: "floral" },
    { id: "mat_notebook_blush_emb", name: "Shaftolirang Gulli Yaltiroq", color: "#ecc0b2", shimmer: "floral_shimmer" },
    { id: "mat_notebook_yellow_silk", name: "Sariq Akvarel Ipak (Notebook)", color: "#f2c230", shimmer: "satin" },
    { id: "mat_notebook_ice_pleat", name: "Havorang Plisse Shifon", color: "#b7cde2", shimmer: "satin" },
    { id: "mat_silk_satin", name: "Ipak Atlas (Silk Satin)", color: "#c99b94", shimmer: "satin" },
    { id: "mat_liquid_gold", name: "Yaltiroq Suyuq Oltin (Gold Lamé)", color: "#d4af37", shimmer: "sequin_gold" },
    { id: "mat_silver_sequin", name: "Kumush Tangacha (Silver Sequin)", color: "#cfd6dc", shimmer: "sequin_silver" },
    { id: "mat_rose_glitter", name: "Pushti Olmos Yaltiroq (Rose Shimmer)", color: "#e09ca8", shimmer: "glitter_rose" },
    { id: "mat_crystal_mesh", name: "Billur Swarovski To'r (Crystal Mesh)", color: "#e6ecf2", shimmer: "crystal" },
    { id: "mat_ruby_sequin", name: "Yoqut Yaltiroq Payetka (Ruby Sequin)", color: "#7a1428", shimmer: "sequin_gold" },
    { id: "mat_emerald_lame", name: "Zumrad Metallik (Emerald Lamé)", color: "#1d5952", shimmer: "glitter_silver" },
    { id: "mat_midnight_stardust", name: "Yulduzli Qora Baxmal (Stardust)", color: "#1c1829", shimmer: "crystal" },
    { id: "mat_pearl_organza", name: "Marvarid Yaltiroq Shoyi (Pearl)", color: "#f2ece1", shimmer: "satin" },
    { id: "mat_champagne_brocade", name: "Shampan Oltin Parcha (Brocade)", color: "#c9b07a", shimmer: "sequin_gold" }
  ],

  dresses: [
    { id: "none", name: "Olib tashlash" },
    { id: "dress_exact_1", imgSrc: "assets/dress_exact_1.png", name: "1. Kundalik Ko'k Denim", x: 112, y: 92, w: 136, h: 192 },
    { id: "dress_exact_2", imgSrc: "assets/dress_exact_2.png", name: "2. Qizil Casual Ko'ylak", x: 116, y: 95, w: 128, h: 192 },
    { id: "dress_exact_3", imgSrc: "assets/dress_exact_3.png", name: "3. Binafsha Kokteyl", x: 124, y: 96, w: 112, h: 208 },
    { id: "dress_exact_4", imgSrc: "assets/dress_exact_4.png", name: "4. Kechki Muz-Yashil Gown", x: 74, y: 94, w: 212, h: 344 },
    { id: "dress_exact_5", imgSrc: "assets/dress_exact_5.png", name: "5. Kulrang Sheath Midi", x: 130, y: 94, w: 100, h: 212 },
    { id: "dress_exact_6", imgSrc: "assets/dress_exact_6.png", name: "6. Moviy Plisseli Midi", x: 108, y: 94, w: 144, h: 244 },
    { id: "dress_exact_7", imgSrc: "assets/dress_exact_7.png", name: "7. Oltin-Krem Ball Gown", x: 70, y: 94, w: 220, h: 346 },
    { id: "dress_exact_8", imgSrc: "assets/dress_exact_8.png", name: "8. Zamonaviy Kombinezon", x: 132, y: 94, w: 96, h: 316 },
    { id: "dress_exact_9", imgSrc: "assets/dress_exact_9.png", name: "9. Sariq A-Line Sundress", x: 110, y: 95, w: 140, h: 204 },
    { id: "dress_exact_10", imgSrc: "assets/dress_exact_10.png", name: "10. Yaltiroq Ipak Gown", x: 108, y: 95, w: 144, h: 342 },
    { id: "dress_exact_11", imgSrc: "assets/dress_exact_11.png", name: "11. Bej Wrap Ko'ylak", x: 126, y: 94, w: 108, h: 248 },
    { id: "dress_exact_12", imgSrc: "assets/dress_exact_12.png", name: "12. Qora Shifon Oqshom", x: 74, y: 94, w: 212, h: 346 },
    { id: "dress_exact_13", imgSrc: "assets/dress_exact_13.png", name: "13. Oq Krujeva Party", x: 100, y: 94, w: 160, h: 204 },
    { id: "dress_exact_14", imgSrc: "assets/dress_exact_14.png", name: "14. Bej Moda Jaket-Ko'ylak", x: 124, y: 93, w: 112, h: 176 }
  ],

  faces: [
    { id: "none", name: "Bo'sh Yuz" },
    { id: "face_editorial_2", imgSrc: "assets/eyes_2.png", name: "1. Uzun Kiprik & Qosh" },
    { id: "face_editorial_3", imgSrc: "assets/eyes_3.png", name: "2. Strelkali Mushuk Ko'z" },
    { id: "face_editorial_1", imgSrc: "assets/eyes_4.png", name: "3. Nafis Bodom Ko'z" },
    { id: "face_editorial_5", imgSrc: "assets/eyes_5.png", name: "4. Tabiiy Qalin Qosh" },
    { id: "face_editorial_8", imgSrc: "assets/eyes_8.png", name: "5. Glamour Kipriklar" },
    { id: "face_editorial_7", imgSrc: "assets/eyes_10.png", name: "6. Smokey Podium Nigoh" },
    { id: "face_editorial_4", imgSrc: "assets/eyes_6.png", name: "7. Sokin Editorial Ko'z" },
    { id: "face_editorial_6", imgSrc: "assets/eyes_1.png", name: "8. Klassik Ingichka Yoy" },
    { id: "face_eyes_7", imgSrc: "assets/eyes_7.png", name: "9. Grafik Qora Strelka" },
    { id: "face_eyes_9", imgSrc: "assets/eyes_9.png", name: "10. Klassik Portret Ko'z" },
    { id: "face_eyes_11", imgSrc: "assets/eyes_11.png", name: "11. Siren Foxy Ko'zlar" },
    { id: "face_eyes_12", imgSrc: "assets/eyes_12.png", name: "12. Eskiz Chizma Ko'z" }
  ],

  hair: [
    { id: "none", name: "Sochsiz" },
    { id: "hair_futuristic_pixie", name: "Futuristik Pixie (Kalta)" },
    { id: "hair_parisian_bob", name: "Klassik Parijcha Bob" },
    { id: "hair_asym_cyber_bob", name: "Asimmetrik Kiber-Bob" },
    { id: "hair_long_waves", name: "Uzun To'lqinli Soch" },
    { id: "hair_hollywood_curls", name: "Havodor Jingalak (Waves)" },
    { id: "hair_sleek_part", name: "Tekis Uzun (O'rtadan)" },
    { id: "hair_side_sweep", name: "Yon Taralgan Glamour" },
    { id: "hair_couture_bun", name: "Baland Couture Topuz (Bun)" },
    { id: "hair_cosmic_chignon", name: "Kosmik Baland Chignon" },
    { id: "hair_low_chignon", name: "Pastki Atelier Chignon" },
    { id: "hair_high_pony", name: "Baland Silliq Ponytail" },
    { id: "hair_braided_crown", name: "Qo'sh O'rilgan (Braids)" },
    { id: "hair_ag_geometric_braid", name: "Anti-Gravity Geometrik O'rim" },
    { id: "hair_ag_floating_rings", name: "Anti-Gravity Kosmik Halqa" }
  ],

  bags: [
    { id: "none", name: "Remove" },
    { id: "bag_birkin", name: "Structured Kelly Tote" },
    { id: "bag_quilted", name: "Quilted Chain Flap" },
    { id: "bag_saddle", name: "Curved Saddle Bag" },
    { id: "bag_mini_chiquito", name: "Micro Top-Handle" },
    { id: "bag_hobo", name: "Crescent Shoulder Bag" },
    { id: "bag_clutch", name: "Geometric Box Clutch" },
    { id: "bag_bucket", name: "Leather Bucket Bag" },
    { id: "bag_shopper", name: "Atelier Tote" }
  ],

  tops: [
    { id: "none", name: "Remove" },
    { id: "top_corset", name: "Boned Corset Bodice" },
    { id: "top_ruffle_shoulder", name: "Draped Ruffle Blouse" },
    { id: "top_blazer", name: "Cinched Couture Blazer" },
    { id: "top_silk_wrap", name: "Surplice Silk Wrap" },
    { id: "top_halter", name: "Draped Halter Top" },
    { id: "top_puff_sleeve", name: "Organza Puff Sleeve" },
    { id: "top_crop_bustier", name: "Sculpted Bustier" }
  ],

  trousers: [
    { id: "none", name: "Remove" },
    { id: "trousers_wide", name: "Tailored Silk Palazzo" },
    { id: "trousers_puff", name: "Gathered Ankle Pant" },
    { id: "trousers_drape", name: "Architectural Drape Pant" },
    { id: "trousers_flare", name: "Elongated Flare" },
    { id: "trousers_skinny", name: "Slim Cigarette Pant" },
    { id: "trousers_culottes", name: "Pleated Midi Culotte" }
  ],

  bottom_details: [
    { id: "none", name: "Remove" },
    { id: "skirt_pencil", name: "High-Waist Pencil Skirt" },
    { id: "skirt_drape", name: "Draped Asymmetric Mini" },
    { id: "skirt_peplum", name: "Sculpted Peplum" },
    { id: "skirt_lace_train", name: "Sheer Tulle Overskirt" },
    { id: "skirt_pleated_midi", name: "Sunburst Pleated Midi" },
    { id: "skirt_tiered_maxi", name: "Tiered Couture Skirt" }
  ],

  belt: [
    { id: "none", name: "Remove" },
    { id: "belt_gold", name: "Gold Atelier Buckle" },
    { id: "belt_ribbon", name: "Silk Grosgrain Sash" },
    { id: "belt_diamond", name: " Pavé Crystal Belt" },
    { id: "belt_corset_wide", name: "Laced Waist Cincher" },
    { id: "belt_pearl_chain", name: "Draped Chain Belt" }
  ],

  shoes: [
    { id: "none", name: "Olib tashlash" },
    { id: "shoe_col_1", imgSrc: "assets/shoe_col_1.png", name: "1. Oltin Baland Posna" },
    { id: "shoe_col_2", imgSrc: "assets/shoe_col_2.png", name: "2. Jigarrang Botinka" },
    { id: "shoe_col_3", imgSrc: "assets/shoe_col_3.png", name: "3. Bej Platforma Sandal" },
    { id: "shoe_col_4", imgSrc: "assets/shoe_col_4.png", name: "4. Nude Klassik Tufli" },
    { id: "shoe_col_5", imgSrc: "assets/shoe_col_5.png", name: "5. Kumush Stiletto" },
    { id: "shoe_col_6", imgSrc: "assets/shoe_col_6.png", name: "6. Oq Klassik Tufli" },
    { id: "shoe_col_7", imgSrc: "assets/shoe_col_7.png", name: "7. Yozgi Yassi Sandal" },
    { id: "shoe_col_8", imgSrc: "assets/shoe_col_8.png", name: "8. Qora Platforma Posna" },
    { id: "shoe_col_9", imgSrc: "assets/shoe_col_9.png", name: "9. Oq Krossovka" },
    { id: "shoe_col_10", imgSrc: "assets/shoe_col_10.png", name: "10. Qora Combat Etik" },
    { id: "shoe_col_11", imgSrc: "assets/shoe_col_11.png", name: "11. Oq Baletka" },
    { id: "shoe_col_12", imgSrc: "assets/shoe_col_12.png", name: "12. Jigarrang Uzun Etik" },
    { id: "shoe_col_13", imgSrc: "assets/shoe_col_13.png", name: "13. Qora Krossovka" },
    { id: "shoe_col_14", imgSrc: "assets/shoe_col_14.png", name: "14. Binafsha Tufli" }
  ],

  stickers: [
    { id: "none", name: "None" },
    { id: "stk_main_title", name: "DIZAYNERLIK STIKERLARI", vb: "345 215 305 140" },
    { id: "stk_men_dizaynerman", name: "MEN DIZAYNERMAN", vb: "202 274 180 65" },
    { id: "stk_creative_design", name: "CREATIVE DESIGN", vb: "698 262 98 62" },
    { id: "stk_creative_mudda", name: "CREATIVE MUDDA", vb: "204 344 112 72" },
    { id: "stk_dizayn_hayoti", name: "DIZAYN HAYOTI", vb: "440 360 120 72" },
    { id: "stk_piksel_mukammal", name: "PIKSEL MUKAMMAL", vb: "676 342 122 72" },
    { id: "stk_pen_bezier", name: "Pen Tool", vb: "206 90 112 108" },
    { id: "stk_layers", name: "Layers", vb: "322 88 106 112" },
    { id: "stk_nib_pencil", name: "Pen & Pencil", vb: "438 82 146 96" },
    { id: "stk_color_wheel", name: "Color Wheel", vb: "590 80 100 100" },
    { id: "stk_brush_win", name: "Brush Window", vb: "696 62 98 104" },
    { id: "stk_palette", name: "Palette", vb: "612 280 76 90" },
    { id: "stk_paint_app", name: "Paint Icon", vb: "706 174 88 82" },
    { id: "stk_protractor", name: "Protractor", vb: "322 338 112 74" },
    { id: "stk_brushes_trio", name: "Brushes Set", vb: "570 370 96 140" },
    { id: "stk_pencils_set", name: "Pencils Set", vb: "328 420 98 90" },
    { id: "stk_wacom_tablet", name: "Graphics Tablet", vb: "448 435 112 74" },
    { id: "stk_gimp_tablet", name: "Canvas Tablet", vb: "204 422 116 90" },
    { id: "stk_dark_monitor", name: "Studio Display", vb: "672 418 126 92" },
    { id: "stk_ruler_yellow", name: "Ruler", vb: "436 176 150 36" },
    { id: "stk_marker_green", name: "Marker", vb: "602 178 86 38" }
  ]
};

const COLOR_PALETTE = [
  "#c99b94", "#dfd3c8", "#5e1929", "#244750", "#1e1d1f",
  "#b08d57", "#87969c", "#3a2d44", "#8c6d58", "#b3727c",
  "#486150", "#c2a878", "#6d526b", "#a39e93", "#e8e4dc"
];

const HAIR_COLOR_PALETTE = [
  "#1e1917", "#362419", "#523422", "#754c29", "#b58e58",
  "#d8c096", "#6e2624", "#3d3542", "#8c6268", "#7a7976"
];

const MARKET_ITEMS = [
  { id: "fabric_silk_pink", category: "mato", typeLabel: "Silk Charmeuse", name: "Blush Silk Roll", svgType: "fabric_roll", desc: "Fine natural silk charmeuse roll.", price: 0, color: "#c99b94", bonusStars: 5 },
  { id: "fabric_velvet_burgundy", category: "mato", typeLabel: "Silk Velvet", name: "Bordeaux Velvet Roll", svgType: "fabric_roll", desc: "Deep wine silk velvet (+10 Stars).", price: 35, color: "#5e1929", bonusStars: 10 },
  { id: "fabric_emerald_satin", category: "mato", typeLabel: "Duchesse Satin", name: "Teal Duchesse Satin", svgType: "fabric_roll", desc: "Lustrous emerald-teal satin (+12 Stars).", price: 40, color: "#244750", bonusStars: 12 },
  { id: "fabric_lace_white", category: "mato", typeLabel: "Chantilly Lace", name: "French Chantilly Lace", svgType: "fabric_lace", desc: "Delicate sheer floral lace (+15 Stars).", price: 50, color: "#dfd3c8", bonusStars: 15 },
  { id: "fabric_gold_brocade", category: "mato", typeLabel: "Metallic Silk", name: "Champagne Gold Silk", svgType: "fabric_roll", desc: "Woven metallic silk roll (+18 Stars).", price: 65, color: "#b08d57", bonusStars: 18 },
  { id: "bag_birkin_gold", category: "sumka", typeLabel: "Atelier Leather", name: "Structured Leather Tote", svgType: "bag_icon", desc: "Handcrafted leather bag (+10 Stars).", price: 0, bonusStars: 10 },
  { id: "bag_quilted_pearl", category: "sumka", typeLabel: "Couture Bag", name: "Quilted Chain Bag", svgType: "bag_icon", desc: "Classic quilted evening bag (+15 Stars).", price: 45, bonusStars: 15 },
  { id: "tool_watercolor", category: "asbob", typeLabel: "Atelier Palette", name: "Watercolor Sketch Palette", svgType: "watercolor_box", desc: "Professional fashion illustration pigments (+15 Stars).", price: 30, bonusStars: 15 },
  { id: "tool_needles", category: "asbob", typeLabel: "Sewing Notions", name: "Couture Pins & Silk Thread", svgType: "needles_spools", desc: "Draping pins and silk spools (+10 Stars).", price: 25, bonusStars: 10 },
  { id: "tool_tape", category: "asbob", typeLabel: "Measuring Tape", name: "Tailor Measuring Tape", svgType: "tape_measure", desc: "Atelier measuring tape (+5 Stars).", price: 0, bonusStars: 5 }
];

const COMPETITORS = [
  { id: "comp_1", name: "Tia Moghrabi", title: "FASHION LEGEND", score: 128822, followers: 4820, following: 312, isFollowing: true, followsYou: true, verified: false },
  { id: "comp_2", name: "MAR (NO AI)", title: "FASHION LEGEND", score: 125579, followers: 3910, following: 195, isFollowing: true, followsYou: true, verified: true },
  { id: "comp_3", name: "LHETYBOOK", title: "FASHION LEGEND", score: 76699, followers: 2150, following: 410, isFollowing: false, followsYou: false, verified: false },
  { id: "comp_4", name: "BEC HANSEN (CR4ZII...", title: "FASHION LEGEND", score: 68384, followers: 1840, following: 275, isFollowing: false, followsYou: false, verified: false },
  { id: "comp_5", name: "ALISHIA", title: "FASHION LEGEND", score: 67422, followers: 1690, following: 520, isFollowing: false, followsYou: true, verified: false }
];

const UNICORN_QUESTIONS = [
  { q: "Yuqori moda (Haute Couture) eskizlarida eng mayin va yaltiroq tabiiy mato qaysi?", options: ["Ipak (Silk Charmeuse)", "Dag'al brezent", "Qalin kigiz", "Sintetik kauchuk"], correct: 0, explanation: "To'g'ri! Tabiiy ipak (Silk) o'zining mayin tovlanishi bilan yuqori modaning asosidir." },
  { q: "Moda dizaynerlari chizadigan nozik ayollar qomati eskizi nima deb ataladi?", options: ["Croquis (Kroki)", "Peyzaj", "Natyurmort", "Mozaika"], correct: 0, explanation: "Barakalla! 'Croquis' — dizaynerlar kiyim loyihalashda foydalanadigan 9-10 bosh o'lchamli nafis model chizmasidir." },
  { q: "Ko'ylak maneken ustida qolipdek turishi uchun qaysi konstruktiv chiziqlar muhim?", options: ["Ko'krak (bust), ingichka bel (waist) va bo'ksa (hip) chiziqlari", "Faqat fon rangi", "Qog'oz qalinligi", "Stiker hajmi"], correct: 0, explanation: "Ajoyib! Ko'krak, bel va bo'ksa chiziqlari libosning qomatga qolipdek o'tirishini ta'minlaydi." },
  { q: "Kiyim eskizlarida matoning shaffofligi va mayin soyalarini berish uchun qaysi bo'yoq ishlatiladi?", options: ["Akvarel (Watercolor)", "Yog'li emal", "Aerozol", "Ko'mir"], correct: 0, explanation: "To'g'ri! Akvarel palitrasi moda eskizlarini jonlantirishda eng qulay vositadir." },
  { q: "Baxmal (Velvet) matosining asosiy xususiyati nimada?", options: ["Yuzasi mayin tukli va chuqur to'q soyali bo'ladi", "Shaffof to'r bo'ladi", "Suv o'tkazmaydigan plastik bo'ladi", "Faqat oq rangda bo'ladi"], correct: 0, explanation: "Ofarin! Baxmal mato yorug'likni o'zgacha yutib, libosga qirollik hashamatini beradi." },
  { q: "Maneken ustida matoni to'g'ridan-to'g'ri ignalar bilan qadab bichish usuli nima deyiladi?", options: ["Moulage / Draping", "Kashtachilik", "To'qimachilik", "Bosma naqsh"], correct: 0, explanation: "To'ppa-to'g'ri! Maneken ustida matoni shakllantirish 'Moulage' (Draping) deyiladi." }
];

const FASHION_EVENTS = [
  {
    id: "ev_ruffle",
    title: "Parisian Ruffle & Sleek Pony",
    desc: "Ingichka belli maneken ustida qat-qat ruffle ko'ylak va baland ponytail soch obrazini yarating.",
    rewardStars: 65,
    preset: { color: "#c99b94", faces: "face_editorial_1", hair: "hair_high_pony", dresses: "dress_ruffle", bags: "bag_birkin", belt: "belt_ribbon", shoes: "heels_boots" }
  },
  {
    id: "ev_palazzo",
    title: "Milan Silk Palazzo & Corset",
    desc: "Keng ipak palazzo shim, qolipdek korset va silliq topuz soch uyg'unligini yarating.",
    rewardStars: 70,
    preset: { color: "#dfd3c8", faces: "face_editorial_3", hair: "hair_couture_bun", trousers: "trousers_wide", tops: "top_corset", bags: "bag_clutch", shoes: "heels_classic" }
  },
  {
    id: "ev_velvet",
    title: "Bordeaux Velvet Evening Gown",
    desc: "To'q qizil baxmal Mermaid oqshom libosini oltin kamar va zanjirli sumka bilan bezang.",
    rewardStars: 85,
    preset: { color: "#5e1929", faces: "face_editorial_5", hair: "hair_long_waves", dresses: "dress_mermaid", belt: "belt_gold", bags: "bag_quilted", shoes: "heels_strappy" }
  }
];

const BADGES_DATA = [
  { id: "ai_explorer", name: "AI Explorer", svg: `<rect x="5" y="8" width="14" height="11" rx="2"/><line x1="12" y1="4" x2="12" y2="8"/><circle cx="12" cy="3" r="1"/><circle cx="9.5" cy="13" r="1"/><circle cx="14.5" cy="13" r="1"/><path d="M9.5 16c1.5 1 3.5 1 5 0"/>` },
  { id: "virtual_stylist", name: "Virtual Stylist", svg: `<path d="M9 4c1 1.5 5 1.5 6 0l2 4-2 3 3 9H6l3-9-2-3 2-4z"/><line x1="9" y1="11" x2="15" y2="11"/>` },
  { id: "style_master", name: "Style Master", svg: `<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2.5-1 2.5-2.2 0-.6-.2-1.1-.6-1.5-.4-.4-.6-.9-.6-1.5 0-1.2 1-2.2 2.2-2.2H17a4 4 0 0 0 4-4c0-3.6-4-6.6-9-6.6z"/><circle cx="8.5" cy="10.5" r="1"/><circle cx="12" cy="8" r="1"/><circle cx="15.5" cy="10.5" r="1"/>` },
  { id: "challenge_lover", name: "Challenge Lover", svg: `<polygon points="13 2 4 14 12 14 11 22 20 10 12 10 13 2"/>` },
  { id: "challenge_champion", name: "Challenge Champion", svg: `<path d="M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M7 6H4v2a3 3 0 0 0 3 3"/><path d="M17 6h3v2a3 3 0 0 1-3 3"/><line x1="12" y1="14" x2="12" y2="19"/><path d="M8 19h8v2H8z"/>` },
  { id: "first_competition", name: "First Competition", svg: `<path d="M6 4h12v6a6 6 0 0 1-12 0V4z"/><path d="M6 6H3v2a3 3 0 0 0 3 3"/><path d="M18 6h3v2a3 3 0 0 1-3 3"/><line x1="12" y1="16" x2="12" y2="20"/><line x1="8" y1="20" x2="16" y2="20"/>` },
  { id: "event_warrior", name: "Event Warrior", svg: `<path d="M12 4l6 3v5c0 4.5-2.6 7.5-6 9-3.4-1.5-6-4.5-6-9V7l6-3z"/><line x1="6" y1="4" x2="18" y2="20"/><line x1="18" y1="4" x2="6" y2="20"/>` },
  { id: "champion", name: "Champion", svg: `<polygon points="3 18 5 7 9.5 12 12 6 14.5 12 19 7 21 18 3 18"/>` },
  { id: "podium_regular", name: "Podium Regular", svg: `<rect x="9" y="11" width="6" height="9"/><rect x="3" y="14" width="6" height="6"/><rect x="15" y="16" width="6" height="4"/><circle cx="12" cy="6" r="2.5"/>` },
  { id: "first_sketch", name: "First Sketch", svg: `<polygon points="16 3 21 8 8 21 3 21 3 16 16 3"/><line x1="13" y1="6" x2="18" y2="11"/>` },
  { id: "prolific_designer", name: "Prolific Designer", svg: `<line x1="12" y1="3" x2="12" y2="21"/><line x1="7" y1="6" x2="11" y2="21"/><line x1="17" y1="6" x2="13" y2="21"/>` },
  { id: "community_debut", name: "Community Debut", svg: `<path d="M12 16V4"/><polyline points="7 9 12 4 17 9"/><path d="M5 14v5h14v-5"/>` }
];

const UNICORN_TIPS = [
  "\"Manekenimiz haqiqiy ayollar moda eskizi (Female Croquis — ingichka bel, nozik bo'yin, nafis qo'l va uzun oyoqlar) shaklida chizildi.\"",
  "\"Soch turmaklari endi yuzni to'sib qo'ymaydi — barchasi professional qalam va tush (ink) texnikasida bosh va yelka atrofida nafis yotadi.\"",
  "\"Yuzlar (Faces) bo'limida kattalarbop Vogue va Parij moda uylari uslubidagi nozik eskiz yuzlari joylashtirildi.\"",
  "\"Barcha ko'ylaklar va korsetlar manekenning ingichka beliga va bo'ksasiga qolipdek tushadi.\""
];

// ============================================================================
// INITIALIZATION
// ============================================================================
window.addEventListener("DOMContentLoaded", () => {
  recalcFollowCounts();
  renderTopStats();
  renderHomeNotebookSketches();
  renderHomeMannequins();
  renderStudioUI();
  renderQuiz();
  renderFashionEvents();
  renderMarket("all");
  renderActivityAndRanking();
  renderProfile();
  initFreehandCanvas();
});

function recalcFollowCounts() {
  state.followingCount = COMPETITORS.filter(c => c.isFollowing).length;
}

function renderTopStats() {
  recalcFollowCounts();
  document.getElementById("headerPlayerName").textContent = state.playerName;
  document.getElementById("welcomePlayerNameSpan").textContent = state.playerName;
  document.getElementById("headerStars").textContent = state.stars.toLocaleString();
  document.getElementById("headerScore").textContent = state.score.toLocaleString();
  document.getElementById("headerFollowers").textContent = state.followersCount.toLocaleString();
  document.getElementById("headerFollowing").textContent = state.followingCount.toLocaleString();
  document.getElementById("heroComboTag").textContent = `SCORE: ${state.score.toLocaleString()} • COMBO x${state.combo}`;

  const marketBal = document.getElementById("marketStarsBalance");
  if (marketBal) marketBal.textContent = state.stars.toLocaleString();
  const profStars = document.getElementById("profileStarsCount");
  if (profStars) profStars.textContent = `${state.stars.toLocaleString()} Yulduz`;
  const profFollowers = document.getElementById("profileFollowersCount");
  if (profFollowers) profFollowers.textContent = state.followersCount.toLocaleString();
  const profFollowing = document.getElementById("profileFollowingCount");
  if (profFollowing) profFollowing.textContent = state.followingCount.toLocaleString();
}

function switchView(viewName) {
  state.activeView = viewName;
  document.querySelectorAll(".view-section").forEach(sec => sec.classList.remove("active"));
  const target = document.getElementById(`view-${viewName}`);
  if (target) target.classList.add("active");

  document.querySelectorAll(".nav-tab").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.view === viewName);
  });

  if (viewName === "studio") {
    renderStudioMannequinStage();
    renderStudioBottomItems();
  } else if (viewName === "market") {
    renderMarket(currentMarketFilter);
  } else if (viewName === "activity") {
    renderActivityAndRanking();
  } else if (viewName === "profile") {
    renderProfile();
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function nextUnicornTip() {
  state.unicornTipIndex = (state.unicornTipIndex + 1) % UNICORN_TIPS.length;
  document.getElementById("unicornHomeSpeech").textContent = UNICORN_TIPS[state.unicornTipIndex];
}

function openUnicornModal() { document.getElementById("unicornWelcomeModal").classList.add("open"); }
function closeUnicornModal() { document.getElementById("unicornWelcomeModal").classList.remove("open"); }

// ============================================================================
// CORE HAUTE-COUTURE FEMALE CROQUIS ENGINE (Exact match to Image 5 & Image 7)
// True 10-head feminine fashion figure with:
// - Small sculpted feminine head: x=166..194, y=28..68 (chin at 180,68)
// - Slender swan neck: x=174..186, y=66..92
// - Sloped delicate feminine shoulders: Left (148,100), Right (212,100)
// - Contoured feminine bust: Left (152,132), Right (208,132)
// - Ultra-cinched feminine hourglass waist: Left (163,164), Right (197,164) — 34px narrow waist!
// - Gracefully curved feminine hips: Left (146,208), Right (214,208)
// - Long, slender feminine legs tapering from y=208 to y=445
// - True layering: hairBack is BEHIND the opaque head/neck/torso so hair NEVER covers the face!
// ============================================================================
function generateFashionSvg(config, isThumbnail = false) {
  const mannequinId = config.mannequinId || "female_pose_1";
  const baseColor = config.color || "#c99b94";
  const hairCol = config.hairColor || state.studio.hairColor || "#2b221e";
  const eq = config.equipped || {};
  const bgStyle = config.bgStyle || "notebook_2024";
  const showGuides = isThumbnail ? false : state.showGuides;
  const mirror = isThumbnail ? false : state.mirrorPose;
  const uid = "svg_" + Math.random().toString(36).substring(2, 8);

  const mObj = MANNEQUINS.find(m => m.id === mannequinId) || MANNEQUINS[0];
  const mannequinImg = mObj.imgSrc || "assets/mannequin_pose_1.png";

  // Background styles including "Ko'ylak Dizayni 2024" Designer Notebook Page
  let bgLayer = `<rect width="360" height="480" fill="#ffffff"/>`;
  let notebookNotesLayer = "";
  if (bgStyle === "notebook_2024") {
    bgLayer = `
      <rect width="360" height="480" fill="#fbf8f1"/>
      <rect x="8" y="8" width="344" height="464" fill="none" stroke="#e4dac8" stroke-width="1"/>
      <line x1="18" y1="8" x2="18" y2="472" stroke="#ece3d3" stroke-width="0.8"/>
      <text x="26" y="29" font-family="Georgia, serif" font-style="italic" font-size="13.5" fill="#4a3c31" font-weight="600">Ko'ylak Dizayni 2024</text>
      <line x1="26" y1="33" x2="148" y2="33" stroke="#cbbba4" stroke-width="0.7"/>
    `;
    if (!isThumbnail && (eq.dresses || eq.tops || eq.trousers)) {
      const matLabel = (GARMENT_ITEMS.materials.find(m => m.id === eq.materials)?.name || "Ipak mato").split("(")[0].trim();
      notebookNotesLayer = `
        <g font-family="Georgia, serif" font-style="italic" font-size="9.5" fill="#6b5c4d" opacity="0.88">
          <text x="242" y="106">Mato turlari:</text>
          <text x="242" y="118" font-size="8.5" fill="#8c6d4e">${matLabel}</text>
          <path d="M238 112 Q220 114 206 122" fill="none" stroke="#8c7a68" stroke-width="0.75" stroke-dasharray="2,2"/>
          <circle cx="206" cy="122" r="1.5" fill="#8c7a68"/>
          <text x="244" y="176">Bel bichimi</text>
          <path d="M240 173 Q220 172 200 165" fill="none" stroke="#8c7a68" stroke-width="0.75" stroke-dasharray="2,2"/>
          <circle cx="200" cy="165" r="1.5" fill="#8c7a68"/>
          <!-- Small fabric swatch card in bottom-left corner -->
          <rect x="24" y="424" width="30" height="30" rx="2" fill="url(#fabric_${uid})" stroke="#8c7a68" stroke-width="0.8"/>
          <text x="60" y="438" font-size="8.5">Namuna</text>
          <text x="60" y="449" font-size="8">Akvarel eskiz</text>
        </g>
      `;
    }
  } else if (bgStyle === "blue_editorial") {
    bgLayer = `
      <rect width="360" height="480" fill="#c6d0d5"/>
      <pattern id="pat_${uid}" width="24" height="24" patternUnits="userSpaceOnUse">
        <path d="M0 12 H24 M12 0 V24" stroke="rgba(255,255,255,0.16)" stroke-width="0.6"/>
      </pattern>
      <rect width="360" height="480" fill="url(#pat_${uid})"/>
    `;
  } else if (bgStyle === "sketch_wings") {
    bgLayer = `
      <rect width="360" height="480" fill="#fbfaf8"/>
      <g stroke="#5c5754" fill="none" opacity="0.42">
        <ellipse cx="104" cy="255" rx="44" ry="136" stroke-width="0.6"/>
        <ellipse cx="112" cy="260" rx="38" ry="124" stroke-width="0.45"/>
        <ellipse cx="256" cy="255" rx="44" ry="136" stroke-width="0.6"/>
        <ellipse cx="248" cy="260" rx="38" ry="124" stroke-width="0.45"/>
      </g>
    `;
  }

  const activeMatObj = GARMENT_ITEMS.materials.find(m => m.id === eq.materials);
  const shimmerType = activeMatObj ? activeMatObj.shimmer : null;
  const isFloralMat = shimmerType === "floral" || shimmerType === "floral_shimmer";
  const isShinyMat = shimmerType && shimmerType !== "satin" && shimmerType !== "floral";

  const defs = `
    <defs>
      <linearGradient id="fabric_${uid}" x1="0%" y1="0%" x2="100%" y2="18%">
        <stop offset="0%" stop-color="${darkenHex(baseColor, isShinyMat ? 28 : 16)}"/>
        <stop offset="22%" stop-color="${lightenHex(baseColor, isShinyMat ? 48 : 22)}"/>
        <stop offset="42%" stop-color="${baseColor}"/>
        <stop offset="56%" stop-color="${isShinyMat ? '#ffffff' : lightenHex(baseColor, 16)}" stop-opacity="${isShinyMat ? '0.95' : '1'}"/>
        <stop offset="72%" stop-color="${baseColor}"/>
        <stop offset="88%" stop-color="${darkenHex(baseColor, isShinyMat ? 32 : 24)}"/>
        <stop offset="100%" stop-color="${lightenHex(baseColor, isShinyMat ? 42 : 10)}"/>
      </linearGradient>
      <pattern id="shimmer_${uid}" width="18" height="18" patternUnits="userSpaceOnUse">
        <rect width="18" height="18" fill="url(#fabric_${uid})"/>
        <circle cx="4" cy="4" r="1.1" fill="#ffffff" opacity="0.85"/>
        <circle cx="13" cy="8" r="0.8" fill="#fff9db" opacity="0.75"/>
        <circle cx="8" cy="14" r="1.2" fill="#ffffff" opacity="0.9"/>
        <circle cx="15" cy="15" r="0.6" fill="#ffffff" opacity="0.7"/>
        <path d="M4 1.5 V6.5 M1.5 4 H6.5 M8 11.5 V16.5 M5.5 14 H10.5" stroke="#ffffff" stroke-width="0.45" opacity="0.85"/>
      </pattern>
      <pattern id="floral_${uid}" width="32" height="32" patternUnits="userSpaceOnUse">
        <rect width="32" height="32" fill="url(#fabric_${uid})"/>
        <!-- Hand-painted watercolor rose & botanical leaves matching Notebook Sketch 2 & 4 -->
        <ellipse cx="9" cy="10" rx="4.2" ry="3.2" fill="#d4687c" opacity="0.78"/>
        <ellipse cx="11" cy="9" rx="2.4" ry="2" fill="#f0a6b3" opacity="0.85"/>
        <circle cx="9.5" cy="10" r="1.2" fill="#9c2c44" opacity="0.7"/>
        <path d="M13 12 Q17 14 15 17 Q12 15 13 12 Z" fill="#6f8c66" opacity="0.78"/>
        <path d="M6 12 Q3 15 6 17 Q8 14 6 12 Z" fill="#5e7a56" opacity="0.75"/>
        <ellipse cx="24" cy="24" rx="4" ry="3" fill="#de7f76" opacity="0.75"/>
        <circle cx="24.5" cy="24" r="1.5" fill="#b34444" opacity="0.68"/>
        <path d="M20 26 Q17 28 20 30 Q22 28 20 26 Z" fill="#7c9671" opacity="0.75"/>
        <circle cx="24" cy="8" r="2.2" fill="#e8b87d" opacity="0.72"/>
        <circle cx="8" cy="26" r="2" fill="#d97b8c" opacity="0.68"/>
        ${shimmerType === "floral_shimmer" ? '<path d="M16 4 V8 M14 6 H18 M28 16 V20 M26 18 H30" stroke="#ffffff" stroke-width="0.6" opacity="0.9"/>' : ''}
      </pattern>
      <linearGradient id="hair_${uid}" x1="0%" y1="0%" x2="100%" y2="15%">
        <stop offset="0%" stop-color="${darkenHex(hairCol, 15)}"/>
        <stop offset="45%" stop-color="${lightenHex(hairCol, 28)}"/>
        <stop offset="100%" stop-color="${darkenHex(hairCol, 18)}"/>
      </linearGradient>
      <linearGradient id="gold_${uid}" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#9c7316"/>
        <stop offset="50%" stop-color="#f5df98"/>
        <stop offset="100%" stop-color="#8f6812"/>
      </linearGradient>
    </defs>
  `;

  // Construction axis lines (matching the exact Female mannequin template)
  const guideLines = showGuides ? `
    <line x1="180" y1="16" x2="180" y2="462" stroke="#d0cac2" stroke-width="0.7" stroke-dasharray="4,4" opacity="0.65"/>
    <line x1="55" y1="130" x2="305" y2="130" stroke="#d0cac2" stroke-width="0.7" stroke-dasharray="4,4" opacity="0.65"/>
  ` : "";

  // 1. HAIR BACK LAYER (Drawn FIRST so it sits cleanly BEHIND the head, neck, and shoulders!)
  const { hairBack, hairFront } = renderEditorialHairSvg(eq.hair, uid, hairCol);

  // 2. EXACT EXTRACTED MANNEQUIN PNG (Copied 100% from user's uploaded image!)
  // Per-pose exact calibration so EVERY dress, top, trouser, skirt & belt molds 100% to the mannequin's real shoulders, bust, waist & hips!
  const poseCal = mannequinId === "female_pose_2"
    ? { cx: 178, sy: 86, sx: 0.96, scaleY: 0.96 }
    : mannequinId === "female_pose_3"
    ? { cx: 174, sy: 83, sx: 0.94, scaleY: 0.95 }
    : { cx: 186, sy: 83, sx: 0.94, scaleY: 0.95 };

  const garmentTransform = `translate(${poseCal.cx}, ${poseCal.sy}) scale(${poseCal.sx}, ${poseCal.scaleY}) translate(-180, -98)`;

  // Inner opaque paper/skin mask strictly inside the head, neck & upper torso so hairBack NEVER bleeds through face or collarbone!
  const maskFill = bgStyle === "notebook_2024" ? "#fdfaf5" : "#ffffff";
  const torsoAndHeadSvg = `
    <ellipse cx="180" cy="45" rx="16" ry="21.5" fill="${maskFill}"/>
    <path d="M172 62 L172 78 L${poseCal.cx - 31} ${poseCal.sy + 3} L${poseCal.cx - 21} ${poseCal.sy + 68} L${poseCal.cx + 21} ${poseCal.sy + 68} L${poseCal.cx + 31} ${poseCal.sy + 3} L188 78 L188 62 Z" fill="${maskFill}"/>
    <image href="${mannequinImg}" x="0" y="0" width="360" height="480" preserveAspectRatio="xMidYMid meet"/>
  `;
  const leftArmOver = "";

  // 4. EDITORIAL FACE SKETCH
  const faceSvg = renderEditorialFaceSvg(eq.faces || "face_editorial_1", uid);

  // ==========================================================================
  // 5. HAUTE COUTURE GARMENTS MOLDED TO THE FEMININE HOURGLASS SILHOUETTE
  // Exact anchors:
  // Shoulders: (148,98)..(212,98)
  // Bust: (152,132)..(208,132)
  // Cinched Waist: (163,164)..(197,164)
  // Hips: (146,208)..(214,208)
  // ==========================================================================
  let garmentsSvg = "";
  const contourStroke = darkenHex(baseColor, 42);
  const foldStroke = darkenHex(baseColor, 32);

  const hourglassBodice = `
    M 148 98 L 166 93 Q 180 114 194 93 L 212 98
    C 210 110, 209 122, 208 132
    C 205 144, 200 154, 197 164
    Q 180 169 163 164
    C 160 154, 155 144, 152 132
    C 151 122, 150 110, 148 98 Z
  `;

  // A. TROUSERS
  if (eq.trousers === "trousers_wide") {
    garmentsSvg += `
      <path d="
        M 163 164 Q 180 169 197 164
        C 205 178, 214 192, 214 208
        L 238 438 L 190 442 L 180 232 L 170 442 L 122 438
        L 146 208 C 146 192, 155 178, 163 164 Z"
        fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M168 168 L144 438 M192 168 L216 438 M174 175 L160 440 M186 175 L200 440" stroke="${foldStroke}" stroke-width="0.7" opacity="0.65"/>
    `;
  } else if (eq.trousers === "trousers_puff") {
    garmentsSvg += `
      <path d="
        M 163 164 Q 180 169 197 164
        C 216 185, 224 255, 212 385 L 220 416 L 188 416 L 192 385 L 180 232 L 168 385 L 172 416 L 140 416 L 148 385
        C 136 255, 144 185, 163 164 Z"
        fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.trousers === "trousers_drape") {
    garmentsSvg += `
      <path d="M163 164 L197 164 L244 312 L204 388 L180 234 L156 388 L116 312 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.trousers === "trousers_flare") {
    garmentsSvg += `
      <path d="M163 164 L197 164 L214 208 L206 326 L242 442 L188 442 L180 232 L172 442 L118 442 L154 326 L146 208 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.trousers === "trousers_skinny") {
    garmentsSvg += `
      <path d="M163 164 Q180 169 197 164 C205 178 214 192 214 208 L202 418 L186 418 L180 230 L174 418 L158 418 L146 208 C146 192 155 178 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.trousers === "trousers_culottes") {
    garmentsSvg += `
      <path d="M163 164 L197 164 L232 355 L184 355 L180 232 L176 355 L128 355 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  }

  // B. TOPS & CORSETS
  if (eq.tops === "top_corset") {
    garmentsSvg += `
      <path d="
        M 152 120 C 160 112 173 118 180 126 C 187 118 200 112 208 120
        C 205 138, 200 152, 197 164
        Q 180 172 163 164
        C 160 152, 155 138, 152 120 Z"
        fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M180 126 V168 M166 118 L169 166 M194 118 L191 166" stroke="${foldStroke}" stroke-width="0.7" opacity="0.65"/>
    `;
  } else if (eq.tops === "top_ruffle_shoulder") {
    garmentsSvg += `
      <path d="M130 98 C144 86 158 94 168 114 L192 114 C202 94 216 86 230 98 L208 132 L197 164 L163 164 L152 132 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.tops === "top_blazer") {
    garmentsSvg += `
      <path d="M144 96 L166 92 L180 140 L194 92 L216 96 L199 164 L214 204 L146 204 L161 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.tops === "top_silk_wrap") {
    garmentsSvg += `
      <path d="${hourglassBodice}" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <line x1="156" y1="106" x2="197" y2="164" stroke="${foldStroke}" stroke-width="0.85"/>
    `;
  } else if (eq.tops === "top_halter") {
    garmentsSvg += `
      <path d="M168 90 L192 90 L208 132 L197 164 L163 164 L152 132 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.tops === "top_puff_sleeve") {
    garmentsSvg += `
      <path d="M128 106 C126 88 144 86 154 98 L206 98 C216 86 234 88 232 106 L208 132 L197 164 L163 164 L152 132 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.tops === "top_crop_bustier") {
    garmentsSvg += `
      <path d="M152 120 Q166 110 180 124 Q194 110 208 120 L201 150 L159 150 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  }

  // C. SKIRTS
  if (eq.bottom_details === "skirt_pencil") {
    garmentsSvg += `
      <path d="M163 164 Q180 169 197 164 C205 178 214 192 214 208 C214 252 206 298 200 338 Q180 344 160 338 C154 298 146 252 146 208 C146 192 155 178 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.bottom_details === "skirt_drape") {
    garmentsSvg += `
      <path d="M163 164 Q180 169 197 164 C205 178 214 192 214 208 C214 234 210 256 206 272 Q180 280 154 272 C150 256 146 234 146 208 C146 192 155 178 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.bottom_details === "skirt_peplum") {
    garmentsSvg += `
      <path d="M163 164 L197 164 C214 182 228 200 232 216 Q180 230 128 216 C132 200 146 182 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.bottom_details === "skirt_lace_train") {
    garmentsSvg += `
      <path d="M163 164 L197 164 C232 238 256 330 268 424 Q180 444 92 424 C104 330 128 238 163 164 Z"
            fill="url(#fabric_${uid})" fill-opacity="0.46" stroke="${contourStroke}" stroke-width="1.05" stroke-dasharray="3,2"/>
    `;
  } else if (eq.bottom_details === "skirt_pleated_midi") {
    garmentsSvg += `
      <path d="M163 164 L197 164 L236 355 Q180 368 124 355 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.bottom_details === "skirt_tiered_maxi") {
    garmentsSvg += `
      <path d="M163 164 L197 164 L220 242 L140 242 Z M140 242 L220 242 L242 332 L118 332 Z M118 332 L242 332 L260 428 L100 428 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  }

  // D. EXACT USER-UPLOADED DRESSES (100% unchanged PNG cutouts aligned to mannequin!)
  const exactDressObj = GARMENT_ITEMS.dresses.find(d => d.id === eq.dresses && d.imgSrc);
  if (exactDressObj) {
    garmentsSvg += `
      <image href="${exactDressObj.imgSrc}"
             x="${exactDressObj.x}" y="${exactDressObj.y}"
             width="${exactDressObj.w}" height="${exactDressObj.h}"
             preserveAspectRatio="xMidYMin meet" />
    `;
  } else if (eq.dresses === "dress_notebook_yellow") {
    // Notebook Sketch 1: Golden-Yellow Puff-Sleeve V-Neck Belted Midi Dress
    garmentsSvg += `
      <!-- Romantic Puff Sleeves -->
      <path d="M148 94 C132 88 124 106 134 122 C142 126 150 120 154 112 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <path d="M212 94 C228 88 236 106 226 122 C218 126 210 120 206 112 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <!-- Surplice V-Neck Fitted Bodice -->
      <path d="M148 94 L166 90 L180 128 L194 90 L212 94 C208 118 202 144 198 162 Q180 168 162 162 C158 144 152 118 148 94 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <path d="M166 90 L184 134 M194 90 L176 134" stroke="${foldStroke}" stroke-width="0.8" opacity="0.7"/>
      <!-- Flowing Belted A-Line Midi Skirt with Watercolor Drapery Folds -->
      <path d="M162 162 Q180 168 198 162 C214 202 232 262 246 336 Q216 346 198 338 Q180 350 162 338 Q144 346 114 336 C128 262 146 202 162 162 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <path d="M168 166 L142 338 M176 168 L166 342 M184 168 L194 342 M192 166 L218 338" stroke="${foldStroke}" stroke-width="0.7" opacity="0.65"/>
      <!-- Matching Tie Waist Belt -->
      <rect x="160" y="159" width="40" height="6" rx="2" fill="${darkenHex(baseColor, 20)}" stroke="${contourStroke}" stroke-width="0.9"/>
      <circle cx="180" cy="142" r="1.5" fill="${contourStroke}"/><circle cx="180" cy="151" r="1.5" fill="${contourStroke}"/>
    `;
  } else if (eq.dresses === "dress_notebook_floral_maxi") {
    // Notebook Sketch 2: Floor-Length Floral Watercolor Maxi Evening Gown
    garmentsSvg += `
      <!-- Delicate Shoulder Straps & Sweetheart Fitted Bodice -->
      <path d="M158 92 L162 118 M202 92 L198 118" stroke="${contourStroke}" stroke-width="1.6"/>
      <path d="M154 116 Q168 108 180 122 Q192 108 206 116 C203 136 200 148 197 162 Q180 168 163 162 C160 148 157 136 154 116 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <!-- Sweeping Floor-Length Maxi Skirt -->
      <path d="M163 162 Q180 168 197 162 C218 224 242 325 258 436 Q224 446 200 438 Q180 450 160 438 Q136 446 102 436 C118 325 142 224 163 162 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <path d="M168 165 L132 438 M175 167 L160 442 M185 167 L200 442 M192 165 L228 438" stroke="${foldStroke}" stroke-width="0.7" opacity="0.55"/>
    `;
  } else if (eq.dresses === "dress_notebook_iceblue") {
    // Notebook Sketch 3: Ice-Blue Off-Shoulder Draped Pleated Midi Dress
    garmentsSvg += `
      <!-- Off-Shoulder Draped Neckline & Sheer Flutter Sleeves -->
      <path d="M132 108 Q156 122 180 116 Q204 122 228 108 C230 122 224 134 212 132 L206 130 L197 162 Q180 168 163 162 L154 130 L148 132 C136 134 130 122 132 108 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <!-- Sunburst Knife-Pleated Midi Skirt -->
      <path d="M163 162 Q180 168 197 162 L244 334 Q180 348 116 334 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <!-- Crisp Hand-Drawn Sunburst Pleats -->
      <path d="M166 164 L132 336 M171 165 L148 338 M176 166 L165 340 M180 166 L180 341 M184 166 L195 340 M189 165 L212 338 M194 164 L228 336"
            stroke="${foldStroke}" stroke-width="0.65" opacity="0.68"/>
      <!-- Slim Velvet Waist Ribbon -->
      <rect x="162" y="160" width="36" height="4.5" fill="#2c3545"/>
    `;
  } else if (eq.dresses === "dress_notebook_blush_floral") {
    // Notebook Sketch 4: Blush-Peach Floral & Embroidered A-Line Cocktail Dress
    garmentsSvg += `
      <!-- Sculpted Sleeveless Bodice -->
      <path d="M154 94 L166 92 Q180 112 194 92 L206 94 C205 118 201 142 197 162 Q180 168 163 162 C159 142 155 118 154 94 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <!-- Flared Above-the-Knee Cocktail Skirt -->
      <path d="M163 162 Q180 168 197 162 C214 194 230 236 240 278 Q212 288 180 282 Q148 288 120 278 C130 236 146 194 163 162 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.15"/>
      <path d="M168 166 L142 280 M180 166 L180 282 M192 166 L218 280" stroke="${foldStroke}" stroke-width="0.65" opacity="0.6"/>
      <rect x="162" y="160" width="36" height="4.5" rx="1.5" fill="${darkenHex(baseColor, 22)}"/>
    `;
  } else if (eq.dresses === "dress_ruffle") {
    // Exact match to Image 5 Left Card & Image 1 Center Dress!
    garmentsSvg += `
      <path d="M152 120 C160 112 173 118 180 126 C187 118 200 112 208 120 C205 138 200 152 197 164 Q180 170 163 164 C160 152 155 138 152 120 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <!-- Tier 1 -->
      <path d="M163 164 L197 164 C212 182 224 200 228 214 Q180 226 132 214 C136 200 148 182 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <!-- Tier 2 -->
      <path d="M136 212 L224 212 L242 246 Q180 260 118 246 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <!-- Tier 3 -->
      <path d="M124 244 L236 244 L250 276 Q180 290 110 276 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M168 166 L148 278 M180 166 L180 282 M192 166 L212 278" stroke="${foldStroke}" stroke-width="0.65" opacity="0.65"/>
    `;
  } else if (eq.dresses === "dress_bodycon_midi") {
    garmentsSvg += `
      <path d="
        M 148 98 L 166 93 Q 180 114 194 93 L 212 98
        C 210 110, 209 122, 208 132
        C 205 144, 200 154, 197 164
        C 205 178, 214 192, 214 208
        C 214 252, 206 298, 200 338
        Q 180 345 160 338
        C 154 298, 146 252, 146 208
        C 146 192, 155 178, 163 164
        C 160 154, 155 144, 152 132
        C 151 122, 150 110, 148 98 Z"
        fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M163 164 Q180 169 197 164 M164 100 L168 164 L162 338 M196 100 L192 164 L198 338" fill="none" stroke="${foldStroke}" stroke-width="0.65" opacity="0.55"/>
    `;
  } else if (eq.dresses === "dress_mermaid") {
    garmentsSvg += `
      <path d="
        M 152 120 C 160 112 173 118 180 126 C 187 118 200 112 208 120
        C 205 138, 200 152, 197 164
        C 205 178, 214 192, 214 208
        C 214 252, 206 298, 200 334
        C 220 372, 244 410, 256 444
        Q 180 460 104 444
        C 116 410, 140 372, 160 334
        C 154 298, 146 252, 146 208
        C 146 192, 155 178, 163 164
        C 160 152, 155 138, 152 120 Z"
        fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M160 334 Q180 344 200 334 M170 338 L136 448 M180 340 L180 452 M190 338 L224 448" fill="none" stroke="${foldStroke}" stroke-width="0.7" opacity="0.6"/>
    `;
  } else if (eq.dresses === "dress_corset_mini") {
    garmentsSvg += `
      <path d="
        M 152 120 C 160 112 173 118 180 126 C 187 118 200 112 208 120
        C 205 138, 200 152, 197 164
        C 205 178, 214 192, 214 208
        C 214 228, 211 246, 208 262
        Q 180 270 152 262
        C 149 246, 146 228, 146 208
        C 146 192, 155 178, 163 164
        C 160 152, 155 138, 152 120 Z"
        fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.dresses === "dress_ballgown") {
    garmentsSvg += `
      <path d="${hourglassBodice}" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M163 164 L197 164 C236 234 264 335 278 438 Q180 458 82 438 C96 335 124 234 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M170 166 L122 442 M180 166 L180 448 M190 166 L238 442" stroke="${foldStroke}" stroke-width="0.75" opacity="0.6"/>
    `;
  } else if (eq.dresses === "dress_emerald") {
    garmentsSvg += `
      <path d="${hourglassBodice}" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M163 164 L197 164 C216 192 242 234 254 276 C232 296 210 300 188 286 C172 306 148 302 124 280 C134 234 150 192 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.dresses === "dress_aline") {
    garmentsSvg += `
      <path d="${hourglassBodice}" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M163 164 L197 164 L236 355 Q180 368 124 355 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.dresses === "dress_asym") {
    garmentsSvg += `
      <path d="M148 98 L166 93 L208 132 L197 164 L214 208 L236 382 L138 282 L146 208 L163 164 L152 132 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.dresses === "dress_velvet_sheath") {
    garmentsSvg += `
      <path d="M166 93 L194 93 L212 98 L208 132 L197 164 L214 208 L206 312 Q180 320 154 312 L146 208 L163 164 L152 132 L148 98 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.dresses === "dress_offshoulder") {
    garmentsSvg += `
      <path d="M134 110 Q180 124 226 110 L220 128 L208 132 L197 164 L214 208 L244 438 Q180 452 116 438 L146 208 L163 164 L152 132 L140 128 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.dresses === "dress_halter_slit") {
    garmentsSvg += `
      <path d="M168 90 L192 90 L208 132 L197 164 L214 208 L230 438 L192 438 L186 286 L168 438 L130 438 L146 208 L163 164 L152 132 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  } else if (eq.dresses === "dress_bridal") {
    garmentsSvg += `
      <path d="${hourglassBodice}" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      <path d="M163 164 L197 164 C242 234 274 338 292 442 Q180 464 68 442 C86 338 118 234 163 164 Z"
            fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
    `;
  }

  // E. BELTS (Cinched waist x=163..197 at y=164)
  if (eq.belt === "belt_gold") {
    garmentsSvg += `
      <rect x="162" y="161" width="36" height="6" rx="1.5" fill="url(#gold_${uid})" stroke="#5c4209" stroke-width="0.8"/>
      <rect x="176" y="159.5" width="8" height="9" rx="1" fill="none" stroke="url(#gold_${uid})" stroke-width="1.5"/>
    `;
  } else if (eq.belt === "belt_ribbon") {
    garmentsSvg += `
      <rect x="162" y="161.5" width="36" height="5" fill="#1f1c1d"/>
      <path d="M180 165 L168 214 M180 165 L192 214" stroke="#1f1c1d" stroke-width="2.5" stroke-linecap="round"/>
    `;
  } else if (eq.belt === "belt_diamond") {
    garmentsSvg += `
      <rect x="162" y="161.5" width="36" height="5" fill="#e8eef2" stroke="#5a656e" stroke-width="0.8"/>
      <polygon points="180,158 184,164 180,170 176,164" fill="#ffffff" stroke="#5a656e" stroke-width="0.8"/>
    `;
  } else if (eq.belt === "belt_corset_wide") {
    garmentsSvg += `
      <path d="M159 152 L201 152 L197 174 L163 174 Z" fill="#1f1c1d" stroke="url(#gold_${uid})" stroke-width="1.1"/>
    `;
  } else if (eq.belt === "belt_pearl_chain") {
    garmentsSvg += `
      <path d="M163 164 Q180 176 197 164 Q188 184 180 180" fill="none" stroke="#fdfbf7" stroke-width="2.6" stroke-dasharray="2,3.5" stroke-linecap="round"/>
    `;
  }

  // F. BAGS
  if (eq.bags === "bag_birkin") {
    garmentsSvg += `
      <g transform="translate(220, 206)">
        <path d="M12 16 C12 2 28 2 28 16" fill="none" stroke="#231f20" stroke-width="1.8"/>
        <path d="M4 16 H36 L40 46 H0 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
        <path d="M4 16 L20 26 L36 16" fill="none" stroke="${contourStroke}" stroke-width="1"/>
        <rect x="18" y="23" width="4" height="6" fill="url(#gold_${uid})"/>
      </g>
    `;
  } else if (eq.bags === "bag_quilted") {
    garmentsSvg += `
      <g transform="translate(220, 198)">
        <path d="M8 28 C8 4 32 4 32 28" fill="none" stroke="url(#gold_${uid})" stroke-width="1.5" stroke-dasharray="3,2"/>
        <rect x="4" y="28" width="32" height="22" rx="2" fill="#1f1c1d" stroke="url(#gold_${uid})" stroke-width="1.1"/>
        <circle cx="20" cy="39" r="2.5" fill="url(#gold_${uid})"/>
      </g>
    `;
  } else if (eq.bags === "bag_saddle") {
    garmentsSvg += `
      <g transform="translate(220, 206)">
        <path d="M10 14 C10 2 28 2 28 14" fill="none" stroke="#231f20" stroke-width="1.8"/>
        <path d="M4 14 H34 C38 30 30 42 18 40 C6 38 2 26 4 14 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
        <circle cx="20" cy="29" r="3" fill="url(#gold_${uid})"/>
      </g>
    `;
  } else if (eq.bags === "bag_mini_chiquito") {
    garmentsSvg += `
      <g transform="translate(224, 210)">
        <path d="M7 15 C7 2 23 2 23 15" fill="none" stroke="#231f20" stroke-width="2"/>
        <path d="M3 15 H27 L30 33 H0 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.1"/>
      </g>
    `;
  } else if (eq.bags === "bag_hobo") {
    garmentsSvg += `
      <g transform="translate(220, 204)">
        <path d="M6 18 C6 4 32 4 32 18 C36 34 28 44 19 44 C10 44 2 34 6 18 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
        <ellipse cx="19" cy="15" rx="8" ry="6" fill="#faf8f5" stroke="${contourStroke}" stroke-width="1"/>
      </g>
    `;
  } else if (eq.bags === "bag_clutch") {
    garmentsSvg += `
      <g transform="translate(218, 210)">
        <rect x="2" y="4" width="32" height="18" rx="3" fill="url(#gold_${uid})" stroke="#5c4209" stroke-width="1.1"/>
      </g>
    `;
  } else if (eq.bags === "bag_bucket") {
    garmentsSvg += `
      <g transform="translate(222, 206)">
        <path d="M10 14 C10 2 26 2 26 14" fill="none" stroke="#231f20" stroke-width="1.6"/>
        <path d="M4 14 H32 L28 42 H8 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.1"/>
      </g>
    `;
  } else if (eq.bags === "bag_shopper") {
    garmentsSvg += `
      <g transform="translate(218, 206)">
        <path d="M12 16 C12 4 28 4 28 16" fill="none" stroke="#231f20" stroke-width="1.8"/>
        <rect x="2" y="16" width="36" height="36" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.2"/>
      </g>
    `;
  }

  // G. EXACT USER-UPLOADED FOOTWEAR (Split Left & Right PNGs placed directly on each foot!)
  let shoesSvg = "";
  const exactShoeObj = GARMENT_ITEMS.shoes.find(s => s.id === eq.shoes && s.imgSrc);
  if (exactShoeObj) {
    const baseSrc = exactShoeObj.imgSrc.replace(".png", "");
    const isTallBoot = eq.shoes === "shoe_col_12";
    const isMidBoot = eq.shoes === "shoe_col_2" || eq.shoes === "shoe_col_10";
    const sw = isTallBoot ? 28 : 30;
    const sh = isTallBoot ? 74 : isMidBoot ? 38 : 28;

    let lx = 161, ly = 450 - sh, rx = 228, ry = 456 - sh;
    if (mannequinId === "female_pose_2") {
      lx = 146; ly = 408 - sh;
      rx = 152; ry = 456 - sh;
    } else if (mannequinId === "female_pose_3") {
      lx = 103; ly = 456 - sh;
      rx = 170; ry = 450 - sh;
    }

    shoesSvg = `
      <image href="${baseSrc}_L.png" x="${lx}" y="${ly}" width="${sw}" height="${sh}" preserveAspectRatio="xMidYMax meet" />
      <image href="${baseSrc}_R.png" x="${rx}" y="${ry}" width="${sw}" height="${sh}" preserveAspectRatio="xMidYMax meet" />
    `;
  } else if (eq.shoes === "heels_classic") {
    garmentsSvg += `
      <path d="M162 422 L172 422 L172 446 L160 446 Z" fill="#1d1b1a"/>
      <path d="M222 422 L232 422 L237 446 L225 448 Z" fill="#1d1b1a"/>
    `;
  } else if (eq.shoes === "heels_boots") {
    garmentsSvg += `
      <path d="M155 348 L173 348 L172 446 L160 446 Z" fill="none" stroke="#231f20" stroke-width="1.3"/>
      <path d="M206 348 L222 348 L237 446 L225 448 Z" fill="none" stroke="#231f20" stroke-width="1.3"/>
    `;
  } else if (eq.shoes === "heels_strappy") {
    garmentsSvg += `
      <path d="M163 410 H172 M162 424 H172 M220 410 H230 M222 424 H232" stroke="url(#gold_${uid})" stroke-width="2.2"/>
    `;
  } else if (eq.shoes === "heels_platform") {
    garmentsSvg += `
      <path d="M160 426 H173 L174 448 H159 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.1"/>
      <path d="M222 426 H234 L238 448 H224 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1.1"/>
    `;
  } else if (eq.shoes === "heels_ballet") {
    garmentsSvg += `
      <path d="M161 432 H172 L172 446 H160 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1"/>
      <path d="M223 432 H233 L237 446 H225 Z" fill="url(#fabric_${uid})" stroke="${contourStroke}" stroke-width="1"/>
    `;
  }

  // H. STICKERS
  let decoSvg = "";
  if (eq.stickers && eq.stickers !== "none") {
    const stkObj = GARMENT_ITEMS.stickers.find(s => s.id === eq.stickers);
    if (stkObj && stkObj.vb) {
      let sx = 236, sy = 16, sw = 112, sh = 86;
      if (state.stickerPosition === "top-left") { sx = 12; sy = 16; }
      else if (state.stickerPosition === "bottom-left") { sx = 12; sy = 365; }
      else if (state.stickerPosition === "bottom-right") { sx = 232; sy = 365; }

      decoSvg = `
        <svg x="${sx}" y="${sy}" width="${sw}" height="${sh}" viewBox="${stkObj.vb}">
          <image href="assets/media_1795004351810_3df9f126.jpg" width="1000" height="562" />
        </svg>
      `;
    }
  }

  if (isFloralMat) {
    garmentsSvg = garmentsSvg.replaceAll(`url(#fabric_${uid})`, `url(#floral_${uid})`);
  } else if (isShinyMat) {
    garmentsSvg = garmentsSvg.replaceAll(`url(#fabric_${uid})`, `url(#shimmer_${uid})`);
  }

  const transformGroup = mirror ? `transform="translate(360,0) scale(-1,1)"` : "";

  return `
    ${defs}
    ${bgLayer}
    ${guideLines}
    <g ${transformGroup}>
      ${hairBack}
      ${torsoAndHeadSvg}
      ${faceSvg}
      ${shoesSvg}
      <g transform="${garmentTransform}">
        ${garmentsSvg}
      </g>
      ${leftArmOver}
      ${hairFront}
    </g>
    ${notebookNotesLayer}
    ${decoSvg}
  `;
}

// ============================================================================
// ADULT EDITORIAL FASHION ILLUSTRATION HAIRSTYLES
// Head crown is at y=28, chin at y=70, head width x=166..194.
// Hair NEVER covers the face (x=166..194, y=36..70)!
// ============================================================================
function renderEditorialHairSvg(hairId, uid, hairCol) {
  if (!hairId || hairId === "none") return { hairBack: "", hairFront: "" };
  const strokeCol = darkenHex(hairCol, 25);
  const strandCol = lightenHex(hairCol, 35);

  if (hairId === "hair_high_pony") {
    // Exact match to Image 5 Left Card: Sleek side-swept high ponytail with fine pencil strands!
    return {
      hairBack: `
        <path d="M184 22 C206 18 224 44 218 92 C215 112 208 122 202 106 C208 78 204 42 184 28 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
        <path d="M192 26 C212 44 216 76 208 106 M196 32 C210 54 212 80 205 102"
              fill="none" stroke="${strandCol}" stroke-width="0.65" opacity="0.75"/>
      `,
      hairFront: `
        <path d="M180 25 C168 25 164 33 165 44 C169 35 174 31 180 30 C186 31 191 35 195 44 C196 33 192 25 180 25 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_couture_bun") {
    // Exact match to Image 5 Right Card: Sleek parted chignon/bun on crown
    return {
      hairBack: `
        <ellipse cx="180" cy="21" rx="11" ry="7" fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
      `,
      hairFront: `
        <path d="M180 25 C168 25 164 33 165 44 C169 35 174 31 180 29 C186 31 191 35 195 44 C196 33 192 25 180 25 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
        <line x1="180" y1="25" x2="180" y2="29" stroke="${strandCol}" stroke-width="0.7"/>
      `
    };
  }

  if (hairId === "hair_long_waves") {
    // Flowing runway waves behind the shoulders (torso & head sit IN FRONT of hairBack!)
    return {
      hairBack: `
        <path d="M164 30 C146 44 142 84 146 136 C150 148 160 146 164 132 L196 132 C200 146 210 148 214 136 C218 84 214 44 196 30 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
        <path d="M152 60 Q146 95 152 132 M208 60 Q214 95 208 132" fill="none" stroke="${strandCol}" stroke-width="0.7" opacity="0.65"/>
      `,
      hairFront: `
        <path d="M180 24 C166 24 162 34 164 46 C168 35 174 30 180 28 C186 30 192 35 196 46 C198 34 194 24 180 24 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_sleek_part") {
    return {
      hairBack: `
        <path d="M164 28 L150 96 L154 146 L206 146 L210 96 L196 28 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
      `,
      hairFront: `
        <path d="M180 24 C167 24 163 33 165 44 C169 35 174 30 180 28 C186 30 191 35 195 44 C197 33 193 24 180 24 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_parisian_bob") {
    return {
      hairBack: `
        <path d="M164 28 C152 38 150 64 158 76 L202 76 C210 64 208 38 196 28 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
      `,
      hairFront: `
        <path d="M176 24 C165 25 161 34 163 48 C167 36 172 31 177 29 C185 31 191 36 196 48 C198 34 192 24 176 24 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_side_sweep") {
    return {
      hairBack: `
        <path d="M164 28 C150 45 152 85 162 115 L212 125 C220 90 216 45 196 28 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
      `,
      hairFront: `
        <path d="M172 24 C164 25 162 34 164 45 C168 35 172 30 176 29 C186 31 193 38 196 48 C199 35 192 23 172 24 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_low_chignon") {
    return {
      hairBack: `
        <circle cx="180" cy="64" r="11" fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
      `,
      hairFront: `
        <path d="M180 25 C168 25 164 33 165 44 C169 35 174 31 180 29 C186 31 191 35 195 44 C196 33 192 25 180 25 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_futuristic_pixie") {
    // Short Futuristic Pixie Cut: feathered tapered crown + clean side-swept micro-bangs
    return {
      hairBack: `
        <path d="M163 32 C160 22 172 17 182 18 C194 18 201 26 198 42 L194 46 L166 46 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
      `,
      hairFront: `
        <path d="M164 42 C164 26 173 20 184 21 C193 22 197 30 196 42 C192 33 186 29 178 30 C172 31 168 35 164 42 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
        <path d="M170 25 Q180 23 190 27 M174 28 Q182 26 189 31" fill="none" stroke="${strandCol}" stroke-width="0.6" opacity="0.7"/>
      `
    };
  }

  if (hairId === "hair_asym_cyber_bob") {
    // Futuristic Asymmetric Cyber-Bob: sleek sharp angle longer on one side
    return {
      hairBack: `
        <path d="M164 26 C150 38 148 64 156 78 L196 74 L212 96 C214 66 210 38 196 26 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
        <path d="M204 42 L208 88" fill="none" stroke="${strandCol}" stroke-width="0.65" opacity="0.7"/>
      `,
      hairFront: `
        <path d="M174 23 C164 24 161 33 163 45 C168 34 173 29 179 28 C187 30 192 36 196 46 C198 32 191 22 174 23 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_hollywood_curls") {
    // Classic Voluminous Airy Hollywood Waves cascading past shoulders
    return {
      hairBack: `
        <path d="M163 28 C144 38 136 62 146 82 C136 102 142 128 152 148 C160 156 168 150 172 138 L188 138 C192 150 200 156 208 148 C218 128 224 102 214 82 C224 62 216 38 197 28 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
        <path d="M148 56 Q142 74 150 92 Q144 112 154 136 M212 56 Q218 74 210 92 Q216 112 206 136"
              fill="none" stroke="${strandCol}" stroke-width="0.75" opacity="0.75"/>
      `,
      hairFront: `
        <path d="M174 23 C163 25 160 34 163 46 C168 34 174 29 181 28 C188 30 193 36 197 46 C199 33 192 22 174 23 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_cosmic_chignon") {
    // Elevated Sculptural Cosmic Chignon with Metallic Hair-Pin Halo
    return {
      hairBack: `
        <path d="M166 26 C164 8 196 8 194 26 Z" fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.95"/>
        <ellipse cx="180" cy="14" rx="14" ry="8" fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
        <line x1="158" y1="12" x2="202" y2="18" stroke="url(#gold_${uid})" stroke-width="1.6" stroke-linecap="round"/>
        <circle cx="158" cy="12" r="2" fill="url(#gold_${uid})"/>
        <circle cx="202" cy="18" r="2" fill="url(#gold_${uid})"/>
      `,
      hairFront: `
        <path d="M180 24 C168 24 164 33 165 44 C169 34 174 30 180 28 C186 30 191 34 195 44 C196 33 192 24 180 24 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_ag_geometric_braid") {
    // Anti-Gravity Geometric Sculptural Braid: floating architectural loops & gold cuffs
    return {
      hairBack: `
        <path d="M164 32 C142 14 134 42 152 62 C146 92 152 126 160 156 C165 156 166 122 164 88 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
        <path d="M196 32 C218 14 226 42 208 62 C214 92 208 126 200 156 C195 156 194 122 196 88 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
        <!-- Metallic Anti-Gravity Braid Cuffs -->
        <line x1="152" y1="88" x2="164" y2="88" stroke="url(#gold_${uid})" stroke-width="2"/>
        <line x1="154" y1="118" x2="164" y2="118" stroke="url(#gold_${uid})" stroke-width="2"/>
        <line x1="196" y1="88" x2="208" y2="88" stroke="url(#gold_${uid})" stroke-width="2"/>
        <line x1="196" y1="118" x2="206" y2="118" stroke="url(#gold_${uid})" stroke-width="2"/>
      `,
      hairFront: `
        <path d="M180 23 C166 23 162 33 164 45 C169 34 174 29 180 27 C186 29 191 34 196 45 C198 33 194 23 180 23 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  if (hairId === "hair_ag_floating_rings") {
    // Anti-Gravity Cosmic Sculptural Rings defying gravity around the crown
    return {
      hairBack: `
        <ellipse cx="180" cy="22" rx="26" ry="9" fill="none" stroke="url(#hair_${uid})" stroke-width="5.5"/>
        <ellipse cx="180" cy="22" rx="26" ry="9" fill="none" stroke="url(#gold_${uid})" stroke-width="0.9" stroke-dasharray="6,4"/>
        <path d="M156 26 C144 46 146 72 156 90 M204 26 C216 46 214 72 204 90"
              fill="none" stroke="url(#hair_${uid})" stroke-width="3.2" stroke-linecap="round"/>
      `,
      hairFront: `
        <path d="M180 24 C167 24 163 33 165 44 C169 34 174 30 180 28 C186 30 191 34 195 44 C197 33 193 24 180 24 Z"
              fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
      `
    };
  }

  // hair_braided_crown
  return {
    hairBack: `
      <path d="M164 56 C158 92 156 130 160 162 C164 162 166 130 168 92 Z M196 56 C202 92 204 130 200 162 C196 162 194 130 192 92 Z"
            fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.9"/>
    `,
    hairFront: `
      <path d="M180 24 C167 24 163 33 165 44 C169 35 174 30 180 28 C186 30 191 35 195 44 C197 33 193 24 180 24 Z"
            fill="url(#hair_${uid})" stroke="${strokeCol}" stroke-width="0.85"/>
    `
  };
}

// ============================================================================
// EXACT USER-UPLOADED EYES & EYEBROWS ON MANNEQUIN FACE (12 transparent PNGs)
// Head is x=164..196, y=24..67. Eyes+Brows sit at x=166.5..193.5, y=38.5..50.5
// ============================================================================
function renderEditorialFaceSvg(faceId, uid) {
  if (!faceId || faceId === "none") return "";

  const faceObj = GARMENT_ITEMS.faces.find(f => f.id === faceId) || GARMENT_ITEMS.faces[1];
  const eyesSrc = faceObj && faceObj.imgSrc ? faceObj.imgSrc : "assets/eyes_2.png";
  const noseLine = `<path d="M179.4 49.5 L179 54.2 Q180 55 181.2 54.2" fill="none" stroke="#7a6e67" stroke-width="0.6" stroke-linecap="round"/>`;
  const lipColor = faceId === "face_editorial_3" || faceId === "face_editorial_7" ? "#9e2026" : "#b06c66";

  return `
    <g>
      <image href="${eyesSrc}" x="166.5" y="38.5" width="27" height="12" preserveAspectRatio="xMidYMid meet"/>
      ${noseLine}
      <path d="M176.2 60.2 C177.5 59.1 179 59.1 180 59.7 C181 59.1 182.5 59.1 183.8 60.2 C182.3 62 177.7 62 176.2 60.2 Z" fill="${lipColor}"/>
    </g>
  `;
}

function moveStickerPos(pos) {
  state.stickerPosition = pos;
  renderStudioMannequinStage();
}

function lightenHex(hex, percent) {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.min(255, (num >> 16) + percent);
  const g = Math.min(255, ((num >> 8) & 0x00ff) + percent);
  const b = Math.min(255, (num & 0x0000ff) + percent);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

function darkenHex(hex, percent) {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.max(0, (num >> 16) - percent);
  const g = Math.max(0, ((num >> 8) & 0x00ff) - percent);
  const b = Math.max(0, (num & 0x0000ff) - percent);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

// ============================================================================
// THUMBNAIL PREVIEWS IN STUDIO BOTTOM DRAWER
// ============================================================================
function getTechnicalFlatSvg(cat, item) {
  const itemId = item.id;
  if (itemId === "none") {
    return `<svg width="36" height="36" viewBox="0 0 40 40" fill="none" stroke="#b5b0a8" stroke-width="2"><circle cx="20" cy="20" r="12"/><line x1="12" y1="28" x2="28" y2="12"/></svg>`;
  }
  if (cat === "materials") {
    const col = item.color || "#d4af37";
    const uid = "mat_t_" + itemId;
    return `
      <svg width="56" height="56" viewBox="0 0 60 60">
        <defs>
          <linearGradient id="${uid}" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="${darkenHex(col, 22)}"/>
            <stop offset="35%" stop-color="${lightenHex(col, 42)}"/>
            <stop offset="55%" stop-color="#ffffff"/>
            <stop offset="75%" stop-color="${col}"/>
            <stop offset="100%" stop-color="${darkenHex(col, 18)}"/>
          </linearGradient>
        </defs>
        <rect x="8" y="8" width="44" height="44" rx="6" fill="url(#${uid})" stroke="#2b2624" stroke-width="1"/>
        <path d="M22 16 V26 M17 21 H27 M40 34 V44 M35 39 H45" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round"/>
        <circle cx="38" cy="20" r="2" fill="#ffffff"/>
        <circle cx="20" cy="40" r="1.5" fill="#ffffff"/>
      </svg>
    `;
  }
  if (cat === "stickers" && item.vb) {
    return `<svg width="76" height="56" viewBox="${item.vb}"><image href="assets/media_1795004351810_3df9f126.jpg" width="1000" height="562" /></svg>`;
  }
  if (cat === "faces") {
    if (item.imgSrc) {
      return `<img src="${item.imgSrc}" alt="${item.name}" style="width:76px; height:42px; object-fit:contain;" />`;
    }
    const uid = "thumb_f_" + itemId;
    return `
      <svg width="52" height="58" viewBox="160 24 40 50">
        <path d="M166 45 C166 27 194 27 194 45 C194 58 187 68 180 70 C173 68 166 58 166 45 Z" fill="#fbf7f3" stroke="#36312e" stroke-width="1.1"/>
        ${renderEditorialFaceSvg(itemId, uid)}
      </svg>
    `;
  }
  if (cat === "hair") {
    const uid = "thumb_h_" + itemId;
    const hairCol = state.studio.hairColor || "#2b221e";
    const { hairBack, hairFront } = renderEditorialHairSvg(itemId, uid, hairCol);
    return `
      <svg width="56" height="60" viewBox="142 12 76 95">
        <defs>
          <linearGradient id="hair_${uid}" x1="0%" y1="0%" x2="100%" y2="15%">
            <stop offset="0%" stop-color="${darkenHex(hairCol, 15)}"/>
            <stop offset="50%" stop-color="${lightenHex(hairCol, 28)}"/>
            <stop offset="100%" stop-color="${darkenHex(hairCol, 18)}"/>
          </linearGradient>
        </defs>
        ${hairBack}
        <path d="M166 45 C166 27 194 27 194 45 C194 58 187 68 180 70 C173 68 166 58 166 45 Z" fill="#fbf7f3" stroke="#36312e" stroke-width="1.1"/>
        ${hairFront}
      </svg>
    `;
  }
  if (cat === "bags") {
    return `<svg width="46" height="46" viewBox="0 0 50 50" fill="none" stroke="#141316" stroke-width="1.5"><path d="M17 18 C17 7 33 7 33 18"/><path d="M10 18 H40 L43 42 H7 Z"/><circle cx="25" cy="28" r="2"/></svg>`;
  }
  if (cat === "trousers") {
    return `<svg width="46" height="56" viewBox="0 0 60 70" fill="none" stroke="#141316" stroke-width="1.4"><path d="M18 8 H42 L50 62 H34 L30 24 L26 62 H10 Z"/></svg>`;
  }
  if (cat === "dresses") {
    if (item.imgSrc) {
      return `<img src="${item.imgSrc}" alt="${item.name}" style="width:54px; height:64px; object-fit:contain;" />`;
    }
    return `<svg width="46" height="56" viewBox="0 0 60 70" fill="none" stroke="#141316" stroke-width="1.4"><path d="M18 8 L25 14 H35 L42 8 L38 26 C44 38 46 50 44 62 H16 C14 50 16 38 22 26 Z"/></svg>`;
  }
  if (cat === "shoes") {
    if (item.imgSrc) {
      return `<img src="${item.imgSrc}" alt="${item.name}" style="width:58px; height:48px; object-fit:contain;" />`;
    }
    return `<svg width="44" height="44" viewBox="0 0 50 50" fill="none" stroke="#141316" stroke-width="1.4"><path d="M16 12 H34 L42 40 H8 Z"/></svg>`;
  }
  if (cat === "belt") {
    return `<svg width="46" height="38" viewBox="0 0 60 40" fill="none" stroke="#141316" stroke-width="1.5"><rect x="8" y="16" width="44" height="8"/><rect x="25" y="14" width="10" height="12"/></svg>`;
  }
  if (cat === "tops") {
    return `<svg width="46" height="46" viewBox="0 0 60 60" fill="none" stroke="#141316" stroke-width="1.4"><path d="M16 14 Q24 22 30 16 Q36 22 44 14 L40 46 H20 Z"/></svg>`;
  }
  return `<svg width="44" height="44" viewBox="0 0 50 50" fill="none" stroke="#141316" stroke-width="1.4"><path d="M16 12 H34 L42 40 H8 Z"/></svg>`;
}

// ============================================================================
// HOME VIEW: NOTEBOOK SKETCHES ("Ko'ylak Dizayni 2024") & EXACT MANNEQUIN CARDS
// ============================================================================
function renderHomeNotebookSketches() {
  const grid = document.getElementById("homeNotebookSketchesGrid");
  if (!grid) return;

  grid.innerHTML = NOTEBOOK_SKETCH_PRESETS.map((preset, idx) => {
    const svgArt = generateFashionSvg(preset, false);
    return `
      <div class="portfolio-card" style="cursor:pointer; border:1px solid #d8c3a5;" onclick="loadNotebookSketchPreset(${idx})">
        <div class="portfolio-art-preview" style="height:310px; background:#fbf8f1;">
          <svg viewBox="0 0 360 480" width="100%" height="100%">
            ${svgArt}
          </svg>
        </div>
        <div class="portfolio-card-body">
          <div class="portfolio-card-title">${preset.title}</div>
          <div class="portfolio-card-date">${preset.subtitle}</div>
          <div class="portfolio-actions-row">
            <button class="btn-small-dark" style="width:100%;" onclick="event.stopPropagation(); loadNotebookSketchPreset(${idx})">
              Studiyada Ochish va O'zgartirish →
            </button>
          </div>
        </div>
      </div>
    `;
  }).join("");
}

function loadNotebookSketchPreset(idx) {
  const preset = NOTEBOOK_SKETCH_PRESETS[idx] || NOTEBOOK_SKETCH_PRESETS[0];
  state.activeMannequinId = preset.mannequinId;
  state.editingPortfolioId = null;
  state.studio.dressName = preset.title;
  state.studio.color = preset.color;
  state.studio.hairColor = preset.hairColor;
  state.studio.bgStyle = "notebook_2024";
  state.studio.equipped = {
    faces: preset.equipped.faces || "face_editorial_1",
    hair: preset.equipped.hair || "hair_long_waves",
    materials: preset.equipped.materials || null,
    dresses: preset.equipped.dresses || null,
    tops: null,
    trousers: null,
    bottom_details: null,
    bags: preset.equipped.bags || null,
    belt: preset.equipped.belt || null,
    shoes: preset.equipped.shoes || "heels_classic",
    stickers: null
  };
  renderStudioUI();
  switchView("studio");
}

function renderHomeMannequins() {
  const grid = document.getElementById("homeMannequinGrid");
  if (!grid) return;

  grid.innerHTML = MANNEQUINS.map(m => {
    const previewSvg = generateFashionSvg({
      mannequinId: m.id,
      color: "#c99b94",
      hairColor: "#2b221e",
      bgStyle: "atelier_clean",
      equipped: { faces: "none", hair: "none" }
    }, true);

    const isSelected = state.activeMannequinId === m.id;
    return `
      <div class="mannequin-card ${isSelected ? 'selected' : ''}" onclick="chooseMannequinAndOpenStudio('${m.id}')">
        <div class="mannequin-preview-box" style="height:340px;">
          <svg viewBox="0 0 360 480" width="100%" height="100%">
            ${previewSvg}
          </svg>
        </div>
        <div class="mannequin-name">${m.name}</div>
        <div class="mannequin-pose-sub">${m.subtitle}</div>
        <button class="mannequin-arrow-btn" title="Studiyada ochish">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2">
            <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
          </svg>
        </button>
      </div>
    `;
  }).join("");
}

function chooseMannequinAndOpenStudio(mannequinId) {
  state.activeMannequinId = mannequinId;
  state.editingPortfolioId = null;
  renderHomeMannequins();
  switchView("studio");
}

// ============================================================================
// STUDIO VIEW: INTERACTIVE EDITOR
// ============================================================================
function renderStudioUI() {
  document.getElementById("studioColorSwatches").innerHTML = COLOR_PALETTE.map(c => `
    <button class="color-swatch ${state.studio.color === c ? 'active' : ''}"
            style="background:${c};"
            onclick="selectStudioColor('${c}')"></button>
  `).join("");

  const hairSwatches = document.getElementById("studioHairColorSwatches");
  if (hairSwatches) {
    hairSwatches.innerHTML = HAIR_COLOR_PALETTE.map(c => `
      <button class="color-swatch ${state.studio.hairColor === c ? 'active' : ''}"
              style="background:${c};"
              onclick="selectStudioHairColor('${c}')"></button>
    `).join("");
  }

  document.getElementById("studioCategoryTabs").innerHTML = STUDIO_CATEGORIES.map(cat => `
    <button class="cat-tab-btn ${state.activeCategory === cat.id ? 'active' : ''}"
            onclick="selectStudioCategory('${cat.id}')">
      <span>${cat.label}</span>
    </button>
  `).join("");

  renderStudioMannequinStage();
  renderStudioBottomItems();
}

function renderStudioMannequinStage() {
  const mObj = MANNEQUINS.find(m => m.id === state.activeMannequinId) || MANNEQUINS[0];
  document.getElementById("activeMannequinLabel").textContent = state.editingPortfolioId
    ? `Editing: ${state.studio.dressName}`
    : mObj.name;

  const nameInput = document.getElementById("studioLiveDressName");
  if (nameInput && document.activeElement !== nameInput) {
    nameInput.value = state.studio.dressName;
  }

  document.getElementById("fashionSvgStage").innerHTML = generateFashionSvg({
    mannequinId: state.activeMannequinId,
    color: state.studio.color,
    hairColor: state.studio.hairColor,
    bgStyle: state.studio.bgStyle,
    customText: state.studio.customText,
    equipped: state.studio.equipped
  }, false);
}

function updateLiveDressName(val) {
  state.studio.dressName = val;
}

function selectStudioCategory(catId) {
  state.activeCategory = catId;
  renderStudioUI();
}

function renderStudioBottomItems() {
  const strip = document.getElementById("studioItemsStrip");
  const items = GARMENT_ITEMS[state.activeCategory] || [];
  const currentEquipped = state.studio.equipped[state.activeCategory];

  strip.innerHTML = items.map(item => {
    const isEquipped = (item.id === "none" && !currentEquipped) || (currentEquipped === item.id);
    return `
      <div class="garment-item-card ${isEquipped ? 'equipped' : ''}"
           onclick="handleGarmentItemClick('${state.activeCategory}', '${item.id}')">
        <div style="flex:1; display:flex; align-items:center; justify-content:center;">
          ${getTechnicalFlatSvg(state.activeCategory, item)}
        </div>
        <div class="garment-label">${item.name}</div>
      </div>
    `;
  }).join("");
}

function handleGarmentItemClick(category, itemId) {
  pushStudioHistory();
  if (category === "materials") {
    const matObj = GARMENT_ITEMS.materials.find(m => m.id === itemId);
    state.studio.equipped.materials = itemId;
    if (matObj && matObj.color) {
      state.studio.color = matObj.color;
    }
    if (!state.studio.equipped.dresses && !state.studio.equipped.tops && !state.studio.equipped.trousers && !state.studio.equipped.bottom_details) {
      state.studio.equipped.dresses = "dress_ruffle";
    }
    renderStudioUI();
    return;
  }
  state.studio.equipped[category] = itemId === "none" ? null : itemId;
  renderStudioMannequinStage();
  renderStudioBottomItems();
}

function selectStudioColor(hex) {
  pushStudioHistory();
  state.studio.color = hex;
  renderStudioUI();
}

function selectStudioHairColor(hex) {
  pushStudioHistory();
  state.studio.hairColor = hex;
  if (!state.studio.equipped.hair) {
    state.studio.equipped.hair = "hair_high_pony";
  }
  renderStudioUI();
}

function selectRailTool(toolName) {
  state.activeRailTool = toolName;
  document.querySelectorAll(".rail-tool-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tool === toolName);
  });

  const drawCanvas = document.getElementById("drawOverlayCanvas");
  drawCanvas.classList.toggle("drawing-active", toolName === "draw");

  if (toolName === "clothes") {
    selectStudioCategory("dresses");
  } else if (toolName === "faces") {
    selectStudioCategory("faces");
  } else if (toolName === "hair") {
    selectStudioCategory("hair");
  } else if (toolName === "bags") {
    selectStudioCategory("bags");
  } else if (toolName === "stickers") {
    selectStudioCategory("stickers");
  } else if (toolName === "materials") {
    selectStudioCategory("materials");
  } else if (toolName === "background") {
    const bgs = ["notebook_2024", "atelier_clean", "blue_editorial", "sketch_wings"];
    state.studio.bgStyle = bgs[(bgs.indexOf(state.studio.bgStyle) + 1) % bgs.length];
    renderStudioMannequinStage();
  }
}

function toggleGuideLines() {
  const ids = MANNEQUINS.map(m => m.id);
  state.activeMannequinId = ids[(ids.indexOf(state.activeMannequinId) + 1) % ids.length];
  renderStudioMannequinStage();
}

function toggleMirrorPose() {
  state.mirrorPose = !state.mirrorPose;
  renderStudioMannequinStage();
}

function pushStudioHistory() {
  state.studio.history.push(JSON.stringify({
    color: state.studio.color,
    hairColor: state.studio.hairColor,
    equipped: { ...state.studio.equipped },
    bgStyle: state.studio.bgStyle
  }));
}

function studioUndo() {
  if (!state.studio.history.length) return;
  const prev = JSON.parse(state.studio.history.pop());
  state.studio.redoStack.push(JSON.stringify({
    color: state.studio.color,
    hairColor: state.studio.hairColor,
    equipped: { ...state.studio.equipped },
    bgStyle: state.studio.bgStyle
  }));
  state.studio.color = prev.color;
  state.studio.hairColor = prev.hairColor;
  state.studio.equipped = prev.equipped;
  state.studio.bgStyle = prev.bgStyle;
  renderStudioMannequinStage();
  renderStudioBottomItems();
}

function studioRedo() {
  if (!state.studio.redoStack.length) return;
  const next = JSON.parse(state.studio.redoStack.pop());
  state.studio.color = next.color;
  state.studio.hairColor = next.hairColor;
  state.studio.equipped = next.equipped;
  state.studio.bgStyle = next.bgStyle;
  renderStudioMannequinStage();
  renderStudioBottomItems();
}

function studioReset() {
  pushStudioHistory();
  state.studio.equipped = {
    faces: "face_editorial_1",
    hair: "hair_high_pony",
    dresses: null,
    tops: null,
    trousers: null,
    bottom_details: null,
    bags: null,
    belt: null,
    shoes: null,
    stickers: null
  };
  clearFreehandCanvas();
  renderStudioMannequinStage();
  renderStudioBottomItems();
}

function triggerAiStudioMagic() {
  pushStudioHistory();
  state.studio.color = COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)];
  state.studio.hairColor = HAIR_COLOR_PALETTE[Math.floor(Math.random() * HAIR_COLOR_PALETTE.length)];
  const dressChoices = [
    "dress_exact_1", "dress_exact_2", "dress_exact_3", "dress_exact_4", "dress_exact_5",
    "dress_exact_6", "dress_exact_7", "dress_exact_8", "dress_exact_9", "dress_exact_10",
    "dress_exact_11", "dress_exact_12", "dress_exact_13", "dress_exact_14"
  ];
  const shoeChoices = [
    "shoe_col_1", "shoe_col_2", "shoe_col_4", "shoe_col_5", "shoe_col_6",
    "shoe_col_8", "shoe_col_10", "shoe_col_12", "shoe_col_14"
  ];
  const hairChoices = ["hair_futuristic_pixie", "hair_high_pony", "hair_couture_bun", "hair_long_waves", "hair_hollywood_curls", "hair_cosmic_chignon", "hair_parisian_bob"];
  const faceChoices = ["face_editorial_1", "face_editorial_2", "face_editorial_3", "face_editorial_5", "face_editorial_7", "face_editorial_8"];
  const bagChoices = ["bag_birkin", "bag_quilted", "bag_saddle", "bag_mini_chiquito", "bag_hobo", "bag_clutch"];

  state.studio.equipped = {
    faces: faceChoices[Math.floor(Math.random() * faceChoices.length)],
    hair: hairChoices[Math.floor(Math.random() * hairChoices.length)],
    dresses: dressChoices[Math.floor(Math.random() * dressChoices.length)],
    tops: null,
    trousers: null,
    bottom_details: null,
    bags: bagChoices[Math.floor(Math.random() * bagChoices.length)],
    belt: null,
    shoes: shoeChoices[Math.floor(Math.random() * shoeChoices.length)],
    stickers: null
  };

  unlockBadge("ai_explorer");
  unlockBadge("virtual_stylist");
  renderStudioUI();
}

function initFreehandCanvas() {
  const canvas = document.getElementById("drawOverlayCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let drawing = false;

  const getPos = (e) => {
    const rect = canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: (clientX - rect.left) * (canvas.width / rect.width),
      y: (clientY - rect.top) * (canvas.height / rect.height)
    };
  };

  canvas.addEventListener("mousedown", (e) => {
    if (state.activeRailTool !== "draw") return;
    drawing = true;
    const p = getPos(e);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
  });

  canvas.addEventListener("mousemove", (e) => {
    if (!drawing || state.activeRailTool !== "draw") return;
    const p = getPos(e);
    ctx.lineTo(p.x, p.y);
    ctx.strokeStyle = state.studio.color;
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    ctx.stroke();
  });

  window.addEventListener("mouseup", () => { drawing = false; });
}

function clearFreehandCanvas() {
  const canvas = document.getElementById("drawOverlayCanvas");
  if (canvas) canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
}

// ============================================================================
// FINISH STUDIO -> STARS REWARD & SAVE TO PORTFOLIO / POSTS
// ============================================================================
function finishStudioGame() {
  const equippedCount = Object.values(state.studio.equipped).filter(Boolean).length;
  const earnedStars = 50 + (equippedCount * 12);
  state.combo += 1;
  const earnedScore = earnedStars * 70;

  state.stars += earnedStars;
  state.score += earnedScore;
  unlockBadge("style_master");
  renderTopStats();

  document.getElementById("completedDesignTitleInput").value = state.studio.dressName || "Couture Look";
  document.getElementById("rewardStarsText").textContent = `+${earnedStars} Yulduzcha Qo'shildi`;
  document.getElementById("rewardScoreText").textContent = `+${earnedScore.toLocaleString()} Reyting Balli (COMBO x${state.combo})`;
  document.getElementById("rewardModal").classList.add("open");
}

function saveAndPostDesign(alsoPublishPost) {
  const titleInput = document.getElementById("completedDesignTitleInput").value.trim() || "Couture Look";
  state.studio.dressName = titleInput;

  if (state.editingPortfolioId) {
    const existing = state.portfolio.find(p => p.id === state.editingPortfolioId);
    if (existing) {
      existing.title = titleInput;
      existing.date = "Updated 18/11/2026";
      existing.color = state.studio.color;
      existing.hairColor = state.studio.hairColor;
      existing.bgStyle = state.studio.bgStyle;
      existing.equipped = { ...state.studio.equipped };

      state.posts.forEach(post => {
        if (post.portfolioRefId === existing.id) {
          post.title = existing.title;
          post.color = existing.color;
          post.hairColor = existing.hairColor;
          post.bgStyle = existing.bgStyle;
          post.equipped = { ...existing.equipped };
        }
      });
    }
    state.editingPortfolioId = null;
  } else {
    const newId = "port_" + Date.now();
    const newDesign = {
      id: newId,
      title: titleInput,
      date: "Updated 18/11/2026",
      mannequinId: state.activeMannequinId,
      color: state.studio.color,
      hairColor: state.studio.hairColor,
      bgStyle: state.studio.bgStyle,
      equipped: { ...state.studio.equipped },
      likes: 18
    };
    state.portfolio.unshift(newDesign);

    if (alsoPublishPost) {
      state.stars += 20;
      state.score += 2500;
      state.posts.unshift({
        id: "post_" + Date.now(),
        portfolioRefId: newId,
        author: state.playerName,
        isPlayer: true,
        title: titleInput,
        date: "Updated 18/11/2026",
        mannequinId: newDesign.mannequinId,
        color: newDesign.color,
        hairColor: newDesign.hairColor,
        bgStyle: newDesign.bgStyle,
        equipped: { ...newDesign.equipped },
        likes: 24,
        likedByMe: true
      });
      unlockBadge("podium_regular");
    }
  }

  document.getElementById("rewardModal").classList.remove("open");
  renderTopStats();
  switchView("profile");
}

// ============================================================================
// FOLLOW & FOLLOWING SYSTEM + LIVE ACTIVITY STREAM
// ============================================================================
function toggleFollowDesigner(compId) {
  const comp = COMPETITORS.find(c => c.id === compId);
  if (!comp) return;

  comp.isFollowing = !comp.isFollowing;
  if (comp.isFollowing) {
    comp.followers += 1;
    state.followActivityLog.unshift({
      id: "act_" + Date.now(),
      actor: state.playerName,
      target: comp.name,
      type: "you_followed",
      time: "Just now",
      actorId: comp.id
    });
  } else {
    comp.followers = Math.max(0, comp.followers - 1);
    state.followActivityLog.unshift({
      id: "act_" + Date.now(),
      actor: state.playerName,
      target: comp.name,
      type: "unfollowed",
      time: "Just now",
      actorId: comp.id
    });
  }

  renderTopStats();
  renderActivityAndRanking();
  renderProfile();
}

function simulateIncomingFollower() {
  const randomNames = [
    "Bella Hadid Couture", "Vogue Atelier Paris", "Milan Style Studio",
    "Sofia Laurent", "Amina Fashion House", "Dior Sketcher", "Lola Karimova"
  ];
  const pickName = randomNames[Math.floor(Math.random() * randomNames.length)];
  const followYou = Math.random() > 0.25;

  if (followYou) {
    state.followersCount += 1;
    state.stars += 10;
    state.followActivityLog.unshift({
      id: "act_" + Date.now(),
      actor: pickName,
      target: state.playerName,
      type: "followed_you",
      time: "Just now",
      actorId: "comp_1"
    });
  } else {
    const otherTarget = COMPETITORS[Math.floor(Math.random() * COMPETITORS.length)];
    otherTarget.followers += 1;
    state.followActivityLog.unshift({
      id: "act_" + Date.now(),
      actor: pickName,
      target: otherTarget.name,
      type: "other_follow",
      time: "Just now",
      actorId: otherTarget.id
    });
  }

  renderTopStats();
  renderActivityAndRanking();
  renderProfile();
}

function renderActivityAndRanking() {
  const streamEl = document.getElementById("followActivityStream");
  if (streamEl) {
    streamEl.innerHTML = state.followActivityLog.map(log => {
      const comp = COMPETITORS.find(c => c.id === log.actorId) || COMPETITORS[0];
      const badgeColor = log.type === "followed_you"
        ? "background:#e6f4ea; color:#155724; border:1px solid #b7dfbf;"
        : log.type === "you_followed"
        ? "background:var(--gold-light); color:#6e5211; border:1px solid #dec478;"
        : "background:#f2efe9; color:var(--ink-secondary); border:1px solid var(--border);";

      const actionText = log.type === "followed_you"
        ? `<strong>${log.actor}</strong> started following <strong>${log.target}</strong>`
        : log.type === "you_followed"
        ? `<strong>${log.actor}</strong> started following <strong>${log.target}</strong>`
        : log.type === "unfollowed"
        ? `<strong>${log.actor}</strong> unfollowed <strong>${log.target}</strong>`
        : `<strong>${log.actor}</strong> started following <strong>${log.target}</strong>`;

      return `
        <div class="ranking-row">
          <div class="rank-left">
            <div style="width:42px; height:42px; border-radius:50%; background:#191326; color:#f5d28b; display:flex; align-items:center; justify-content:center; font-family:var(--font-serif); font-weight:700; font-size:18px;">
              ${log.actor.charAt(0)}
            </div>
            <div>
              <div style="font-size:14px; color:var(--ink);">${actionText}</div>
              <div style="font-size:11.5px; color:var(--ink-muted); margin-top:3px;">${log.time}</div>
            </div>
          </div>
          <div style="display:flex; align-items:center; gap:10px;">
            <span style="font-size:11px; font-weight:700; padding:4px 10px; border-radius:4px; ${badgeColor}">
              ${log.type === "followed_you" ? "Follower" : "Following"}
            </span>
            <button class="${comp.isFollowing ? 'btn-small-outline' : 'btn-small-dark'}"
                    onclick="toggleFollowDesigner('${comp.id}')">
              ${comp.isFollowing ? "Following ✓" : "Follow"}
            </button>
          </div>
        </div>
      `;
    }).join("");
  }

  const allPlayers = [
    ...COMPETITORS,
    {
      id: "player_self",
      name: state.playerName,
      title: "FASHION LEGEND",
      score: state.score,
      followers: state.followersCount,
      following: state.followingCount,
      verified: true,
      isPlayer: true
    }
  ].sort((a, b) => b.score - a.score);

  if (allPlayers[0].isPlayer) unlockBadge("champion");

  document.getElementById("globalRankingContainer").innerHTML = allPlayers.map((p, index) => {
    const rank = index + 1;
    const rankClass = rank <= 3 ? `top-${rank}` : "";
    const imgSrc = p.isPlayer || index % 2 === 0
      ? "assets/media_1794928480647_81f73674.jpg"
      : "assets/media_1794849238217_4b172771.jpg";

    return `
      <div class="ranking-row ${p.isPlayer ? 'is-player' : ''}">
        <div class="rank-left">
          <div class="rank-num ${rankClass}">${rank}</div>
          <div class="rank-avatar-wrap">
            <img src="${imgSrc}" alt="${p.name}" class="rank-avatar-img" />
            <span class="rank-badge-circle">${rank}</span>
          </div>
          <div>
            <div class="rank-user-name">
              ${p.name} ${p.verified ? '<span style="color:#2e7d32; font-size:13px;">✓</span>' : ''}
              ${p.followsYou ? '<span style="font-size:10px; background:#efece6; padding:2px 6px; margin-left:6px; font-weight:600;">Follows you</span>' : ''}
            </div>
            <div class="rank-user-title">
              <span>${p.title}</span> •
              <span><strong>${p.followers.toLocaleString()}</strong> Followers</span> •
              <span><strong>${p.following}</strong> Following</span>
            </div>
          </div>
        </div>

        <div style="display:flex; align-items:center; gap:16px;">
          ${!p.isPlayer ? `
            <button class="${p.isFollowing ? 'btn-small-outline' : 'btn-small-dark'}"
                    style="padding:8px 16px; min-width:110px;"
                    onclick="toggleFollowDesigner('${p.id}')">
              ${p.isFollowing ? "Following ✓" : "+ Follow"}
            </button>
          ` : `
            <span style="font-size:11.5px; font-weight:700; color:#6e5211;">You</span>
          `}
          <div class="rank-score-val">${p.score.toLocaleString()}</div>
        </div>
      </div>
    `;
  }).join("");

  const feedGrid = document.getElementById("communityFeedGrid");
  if (state.posts.length === 0) {
    feedGrid.innerHTML = `
      <div style="grid-column:1/-1; background:#fff; border:1px solid var(--border); padding:32px; text-align:center;">
        <h3 style="font-family:var(--font-serif); font-size:24px; margin-bottom:8px;">No Published Posts Yet</h3>
        <p style="font-size:13.5px; color:var(--ink-secondary); margin-bottom:16px;">
          Create a couture look in the Studio and publish it to the Community Feed.
        </p>
        <button class="studio-done-btn" onclick="switchView('studio')">Open Studio →</button>
      </div>
    `;
  } else {
    feedGrid.innerHTML = state.posts.map(post => renderPostCardHTML(post)).join("");
  }
}

function renderPostCardHTML(post) {
  const svgArt = generateFashionSvg(post, true);
  return `
    <div class="portfolio-card">
      <div class="portfolio-art-preview">
        <svg viewBox="0 0 360 480" width="100%" height="100%">
          ${svgArt}
        </svg>
      </div>
      <div class="portfolio-card-body">
        <div class="portfolio-card-title">${post.title}</div>
        <div class="portfolio-card-date">${post.author} • ${post.date}</div>
        <div class="portfolio-actions-row">
          <button class="btn-small-outline" onclick="toggleLikePost('${post.id}')">
            ${post.likedByMe ? '♥' : '♡'} ${post.likes} Likes
          </button>
          ${post.isPlayer && post.portfolioRefId ? `
            <button class="btn-small-outline" onclick="openEditDressModal('${post.portfolioRefId}')">
              Edit Look
            </button>
          ` : ''}
        </div>
      </div>
    </div>
  `;
}

function toggleLikePost(postId) {
  const post = state.posts.find(p => p.id === postId);
  if (!post) return;
  post.likedByMe = !post.likedByMe;
  post.likes += post.likedByMe ? 1 : -1;
  if (post.likedByMe) {
    state.stars += 5;
    state.score += 200;
  }
  renderTopStats();
  renderActivityAndRanking();
  renderProfile();
}

// ============================================================================
// EDIT CREATED DRESSES & RENAME PLAYER
// ============================================================================
let activeModalDressId = null;
let activeModalDressColor = "#c99b94";

function openEditDressModal(portId) {
  const item = state.portfolio.find(p => p.id === portId);
  if (!item) return;
  activeModalDressId = portId;
  activeModalDressColor = item.color;

  document.getElementById("editDressTitleInput").value = item.title;
  renderEditDressModalSwatches();
  document.getElementById("editDressModal").classList.add("open");
}

function renderEditDressModalSwatches() {
  document.getElementById("editDressColorSwatches").innerHTML = COLOR_PALETTE.map(c => `
    <button type="button" class="color-swatch ${activeModalDressColor === c ? 'active' : ''}"
            style="background:${c};"
            onclick="selectModalDressColor('${c}')"></button>
  `).join("");
}

function selectModalDressColor(hex) {
  activeModalDressColor = hex;
  renderEditDressModalSwatches();
}

function applyDressModalChanges() {
  const item = state.portfolio.find(p => p.id === activeModalDressId);
  if (!item) return;

  item.title = document.getElementById("editDressTitleInput").value.trim() || item.title;
  item.color = activeModalDressColor;
  item.date = "Updated 18/11/2026";

  state.posts.forEach(post => {
    if (post.portfolioRefId === item.id) {
      post.title = item.title;
      post.color = item.color;
    }
  });

  closeEditDressModal();
  renderProfile();
  renderActivityAndRanking();
}

function openDressInFullStudio() {
  const portId = activeModalDressId;
  closeEditDressModal();
  loadPortfolioIntoStudio(portId);
}

function closeEditDressModal() { document.getElementById("editDressModal").classList.remove("open"); }

function updatePortfolioTitleInline(portId, newTitle) {
  const item = state.portfolio.find(p => p.id === portId);
  if (!item) return;
  item.title = newTitle.trim() || item.title;
  state.posts.forEach(post => {
    if (post.portfolioRefId === portId) post.title = item.title;
  });
}

function openNameEditorModal() {
  document.getElementById("modalPlayerNameInput").value = state.playerName;
  document.getElementById("nameEditorModal").classList.add("open");
}

function closeNameEditorModal() { document.getElementById("nameEditorModal").classList.remove("open"); }

function saveModalPlayerName() {
  const val = document.getElementById("modalPlayerNameInput").value.trim();
  if (val) applyNewPlayerName(val);
  closeNameEditorModal();
}

function saveInlinePlayerName() {
  const val = document.getElementById("inlinePlayerNameInput").value.trim();
  if (val) applyNewPlayerName(val);
}

function applyNewPlayerName(newName) {
  state.playerName = newName;
  state.posts.forEach(p => { if (p.isPlayer) p.author = newName; });
  renderTopStats();
  renderProfile();
  renderActivityAndRanking();
}

// ============================================================================
// QUIZ, EVENTS & MARKET
// ============================================================================
function renderQuiz() {
  const qObj = UNICORN_QUESTIONS[state.quizIndex % UNICORN_QUESTIONS.length];
  document.getElementById("quizNumberLabel").textContent = `${(state.quizIndex % UNICORN_QUESTIONS.length) + 1} / ${UNICORN_QUESTIONS.length}`;
  document.getElementById("quizQuestionText").textContent = qObj.q;

  document.getElementById("quizOptionsContainer").innerHTML = qObj.options.map((opt, idx) => `
    <button class="quiz-option-btn" onclick="submitQuizAnswer(${idx})">
      ${String.fromCharCode(65 + idx)}. ${opt}
    </button>
  `).join("");

  document.getElementById("quizFeedbackBox").style.display = "none";
}

function submitQuizAnswer(selectedIndex) {
  const qObj = UNICORN_QUESTIONS[state.quizIndex % UNICORN_QUESTIONS.length];
  document.querySelectorAll(".quiz-option-btn").forEach((btn, idx) => {
    btn.disabled = true;
    if (idx === qObj.correct) btn.classList.add("correct");
    else if (idx === selectedIndex) btn.classList.add("wrong");
  });

  const fbBox = document.getElementById("quizFeedbackBox");
  const fbText = document.getElementById("quizFeedbackText");
  fbBox.style.display = "flex";

  if (selectedIndex === qObj.correct) {
    state.stars += 25;
    state.score += 1500;
    state.combo += 1;
    unlockBadge("challenge_lover");
    fbBox.style.background = "#e6f4ea";
    fbBox.style.color = "#155724";
    fbText.textContent = `${qObj.explanation} (+25 Yulduzcha va +1,500 Ball qo'shildi)`;
  } else {
    state.stars += 5;
    fbBox.style.background = "#f7efda";
    fbBox.style.color = "#6e5211";
    fbText.textContent = `${qObj.explanation} (+5 Yulduzcha qo'shildi)`;
  }
  renderTopStats();
}

function loadNextQuizQuestion() {
  state.quizIndex += 1;
  if (state.quizIndex >= 3) unlockBadge("challenge_champion");
  renderQuiz();
}

function renderFashionEvents() {
  const grid = document.getElementById("fashionEventsGrid");
  if (!grid) return;

  grid.innerHTML = FASHION_EVENTS.map(ev => `
    <div class="market-card">
      <div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
          <span style="font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:1.2px; color:var(--ink-muted);">Podium Challenge</span>
          <span style="font-size:12px; font-weight:700; color:#6e5211; background:var(--gold-light); padding:3px 9px;">+${ev.rewardStars} Yulduz</span>
        </div>
        <h3 style="font-family:var(--font-serif); font-size:22px; font-weight:600; margin-bottom:6px;">${ev.title}</h3>
        <p style="font-size:13px; color:var(--ink-secondary); line-height:1.5;">${ev.desc}</p>
      </div>
      <button class="buy-btn" onclick="startThemedEvent('${ev.id}')">Start Challenge →</button>
    </div>
  `).join("");
}

function startThemedEvent(eventId) {
  const ev = FASHION_EVENTS.find(e => e.id === eventId);
  if (!ev) return;
  state.editingPortfolioId = null;
  state.studio.dressName = ev.title;
  state.studio.color = ev.preset.color;
  state.studio.equipped = {
    faces: ev.preset.faces || "face_editorial_1",
    hair: ev.preset.hair || "hair_high_pony",
    dresses: ev.preset.dresses || null,
    tops: ev.preset.tops || null,
    trousers: ev.preset.trousers || null,
    bottom_details: null,
    bags: ev.preset.bags || null,
    belt: ev.preset.belt || null,
    shoes: ev.preset.shoes || "heels_classic",
    stickers: null
  };
  switchView("studio");
}

let currentMarketFilter = "all";

function getMarketVisualSvg(item) {
  if (item.svgType === "fabric_roll" || item.svgType === "fabric_lace") {
    const col = item.color || "#c99b94";
    return `<svg width="120" height="90" viewBox="0 0 120 90" fill="none"><path d="M22 26 C45 14 75 38 102 22 L94 66 C68 80 42 54 14 68 Z" fill="${col}" stroke="#231f20" stroke-width="1.3"/><ellipse cx="22" cy="47" rx="6" ry="21" fill="${darkenHex(col, 30)}" stroke="#231f20" stroke-width="1.2"/></svg>`;
  }
  if (item.svgType === "bag_icon") {
    return `<svg width="90" height="85" viewBox="0 0 60 60" fill="none" stroke="#141316" stroke-width="1.6"><path d="M20 22 C20 8 40 8 40 22"/><path d="M12 22 H48 L52 50 H8 Z" fill="#c99b94"/><rect x="27" y="30" width="6" height="8" fill="#c59b27"/></svg>`;
  }
  if (item.svgType === "watercolor_box") {
    return `<svg width="120" height="90" viewBox="0 0 120 90" fill="none"><rect x="18" y="20" width="76" height="50" rx="4" fill="#f7f4ef" stroke="#231f20" stroke-width="1.4"/><rect x="25" y="27" width="12" height="14" rx="2" fill="#d97b88"/><rect x="41" y="27" width="12" height="14" rx="2" fill="#547a6e"/><rect x="57" y="27" width="12" height="14" rx="2" fill="#4f6496"/><rect x="73" y="27" width="12" height="14" rx="2" fill="#c59b27"/></svg>`;
  }
  return `<svg width="110" height="90" viewBox="0 0 110 90" fill="none"><path d="M18 64 C36 24 68 74 92 28" stroke="#e2d1a0" stroke-width="8" stroke-linecap="round"/><path d="M18 64 C36 24 68 74 92 28" stroke="#231f20" stroke-width="1.2" stroke-dasharray="4,4"/></svg>`;
}

function renderMarket(filterCat = "all") {
  currentMarketFilter = filterCat;
  const filters = [
    { id: "all", label: "All Supplies" },
    { id: "mato", label: "Fabrics (Silk, Velvet, Lace)" },
    { id: "sumka", label: "Luxury Bags" },
    { id: "asbob", label: "Atelier Tools" }
  ];

  document.getElementById("marketFilterBar").innerHTML = filters.map(f => `
    <button class="cat-tab-btn ${filterCat === f.id ? 'active' : ''}" onclick="renderMarket('${f.id}')">${f.label}</button>
  `).join("");

  const items = filterCat === "all" ? MARKET_ITEMS : MARKET_ITEMS.filter(item => item.category === filterCat);

  document.getElementById("marketItemsGrid").innerHTML = items.map(item => {
    const owned = state.ownedMarketIds.includes(item.id);
    return `
      <div class="market-card">
        <div>
          <div class="market-visual"><span class="market-badge-type">${item.typeLabel}</span>${getMarketVisualSvg(item)}</div>
          <h3 style="font-family:var(--font-serif); font-size:20px; font-weight:600; margin-top:12px; margin-bottom:4px;">${item.name}</h3>
          <p style="font-size:12.5px; color:var(--ink-secondary); line-height:1.5;">${item.desc}</p>
        </div>
        ${owned ? `<button class="buy-btn owned" disabled>In Atelier</button>` : `<button class="buy-btn" onclick="buyMarketItem('${item.id}')">Acquire (${item.price} Stars)</button>`}
      </div>
    `;
  }).join("");
}

function buyMarketItem(itemId) {
  const item = MARKET_ITEMS.find(i => i.id === itemId);
  if (!item || state.ownedMarketIds.includes(itemId) || state.stars < item.price) return;
  state.stars -= item.price;
  state.ownedMarketIds.push(itemId);
  state.score += 800;
  if (item.color) state.studio.color = item.color;
  renderTopStats();
  renderMarket(currentMarketFilter);
}

// ============================================================================
// MY PROFILE VIEW
// ============================================================================
function renderProfile() {
  document.getElementById("profilePlayerName").textContent = state.playerName;
  const inlineInput = document.getElementById("inlinePlayerNameInput");
  if (inlineInput && document.activeElement !== inlineInput) inlineInput.value = state.playerName;

  const portGrid = document.getElementById("myPortfolioGrid");
  if (state.portfolio.length === 0) {
    portGrid.innerHTML = `
      <div style="grid-column:1/-1; background:#fff; border:1px solid var(--border); padding:28px; text-align:center;">
        <p style="font-size:14px; color:var(--ink-secondary); margin-bottom:14px;">
          Your Portfolio is currently empty. Design your first couture look in the Studio.
        </p>
        <button class="studio-done-btn" onclick="switchView('studio')">+ Open Studio</button>
      </div>
    `;
  } else {
    portGrid.innerHTML = state.portfolio.map(item => {
      const svgArt = generateFashionSvg(item, true);
      return `
        <div class="portfolio-card">
          <div class="portfolio-art-preview">
            <button class="portfolio-menu-btn" title="Edit" onclick="openEditDressModal('${item.id}')">•••</button>
            <svg viewBox="0 0 360 480" width="100%" height="100%">${svgArt}</svg>
          </div>
          <div class="portfolio-card-body">
            <input type="text" class="inline-title-input" value="${item.title}"
                   oninput="updatePortfolioTitleInline('${item.id}', this.value)" style="margin-bottom:4px;" />
            <div class="portfolio-card-date">${item.date}</div>
            <div class="portfolio-actions-row">
              <button class="btn-small-dark" onclick="openEditDressModal('${item.id}')">Edit</button>
              <button class="btn-small-outline" onclick="loadPortfolioIntoStudio('${item.id}')">Open in Studio</button>
              <button class="btn-small-outline" onclick="quickPublishFromPortfolio('${item.id}')">Post</button>
            </div>
          </div>
        </div>
      `;
    }).join("");
  }

  const myPosts = state.posts.filter(p => p.isPlayer);
  const postsGrid = document.getElementById("myPostsGrid");
  if (myPosts.length === 0) {
    postsGrid.innerHTML = `
      <div style="grid-column:1/-1; background:#fff; border:1px solid var(--border); padding:24px; text-align:center; color:var(--ink-secondary); font-size:13.5px;">
        No published posts yet.
      </div>
    `;
  } else {
    postsGrid.innerHTML = myPosts.map(post => renderPostCardHTML(post)).join("");
  }

  document.getElementById("badgesProgressLabel").textContent = `SEE ALL (${state.unlockedBadges.length} / ${BADGES_DATA.length})`;
  document.getElementById("profileBadgesGrid").innerHTML = BADGES_DATA.map(b => {
    const isUnlocked = state.unlockedBadges.includes(b.id);
    return `
      <div class="badge-item ${isUnlocked ? 'unlocked' : ''}">
        <div class="badge-circle"><svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">${b.svg}</svg></div>
        <div class="badge-name">${b.name}</div>
      </div>
    `;
  }).join("");
}

function loadPortfolioIntoStudio(portId) {
  const item = state.portfolio.find(p => p.id === portId);
  if (!item) return;
  state.editingPortfolioId = item.id;
  state.studio.dressName = item.title;
  state.studio.color = item.color;
  state.studio.hairColor = item.hairColor || "#2b221e";
  state.studio.bgStyle = item.bgStyle;
  state.studio.equipped = { ...item.equipped };
  switchView("studio");
}

function quickPublishFromPortfolio(portId) {
  const item = state.portfolio.find(p => p.id === portId);
  if (!item) return;
  state.posts.unshift({
    id: "post_" + Date.now(),
    portfolioRefId: item.id,
    author: state.playerName,
    isPlayer: true,
    title: item.title,
    date: "Updated 18/11/2026",
    mannequinId: item.mannequinId,
    color: item.color,
    hairColor: item.hairColor,
    bgStyle: item.bgStyle,
    equipped: { ...item.equipped },
    likes: 22,
    likedByMe: true
  });
  state.stars += 20;
  state.score += 2000;
  unlockBadge("podium_regular");
  renderTopStats();
  renderProfile();
  renderActivityAndRanking();
}

function openCreatePostModal() {
  if (state.portfolio.length === 0) {
    switchView("studio");
    return;
  }
  document.getElementById("postPortfolioSelect").innerHTML = state.portfolio.map(p => `<option value="${p.id}">${p.title} (${p.date})</option>`).join("");
  document.getElementById("createPostModal").classList.add("open");
}

function closeCreatePostModal() { document.getElementById("createPostModal").classList.remove("open"); }

function publishSelectedPost() {
  const portId = document.getElementById("postPortfolioSelect").value;
  const caption = document.getElementById("postCaptionInput").value.trim() || "Couture Collection";
  const item = state.portfolio.find(p => p.id === portId) || state.portfolio[0];
  if (item) {
    state.posts.unshift({
      id: "post_" + Date.now(),
      portfolioRefId: item.id,
      author: state.playerName,
      isPlayer: true,
      title: caption,
      date: "Updated 18/11/2026",
      mannequinId: item.mannequinId,
      color: item.color,
      hairColor: item.hairColor,
      bgStyle: item.bgStyle,
      equipped: { ...item.equipped },
      likes: 27,
      likedByMe: true
    });
    state.stars += 20;
    state.score += 2200;
    unlockBadge("podium_regular");
    renderTopStats();
    renderProfile();
    renderActivityAndRanking();
  }
  closeCreatePostModal();
}

function unlockBadge(badgeId) {
  if (!state.unlockedBadges.includes(badgeId)) state.unlockedBadges.push(badgeId);
}

// ============================================================================
// ANTI-GRAVITY AI DIZAYNER & KONSTRUKTOR ENGINE (Shaxsiy Parametrlar + Foto)
// ============================================================================
let agUserPhotoDataUrl = null;
let agLastGeneratedConfig = null;

function handleAgPhotoUpload(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    agUserPhotoDataUrl = e.target.result;
    const wrap = document.getElementById("agPhotoPreviewWrap");
    const img = document.getElementById("agPhotoPreviewImg");
    if (img) img.src = agUserPhotoDataUrl;
    if (wrap) wrap.style.display = "block";
    generateAntiGravityBlueprint(true);
  };
  reader.readAsDataURL(file);
}

function clearAgUserPhoto() {
  agUserPhotoDataUrl = null;
  const wrap = document.getElementById("agPhotoPreviewWrap");
  const inp = document.getElementById("agUserPhotoInput");
  if (wrap) wrap.style.display = "none";
  if (inp) inp.value = "";
  generateAntiGravityBlueprint(true);
}

function generateAntiGravityBlueprint(silent = false) {
  const outEl = document.getElementById("agBlueprintOutput");
  if (!outEl) return;

  const height = Math.max(140, Math.min(205, parseFloat(document.getElementById("agHeightInput")?.value) || 168));
  const weight = Math.max(38, Math.min(130, parseFloat(document.getElementById("agWeightInput")?.value) || 56));
  const faceShape = document.getElementById("agFaceShapeInput")?.value || "oval";
  const paletteKey = document.getElementById("agPaletteInput")?.value || "metallic_chrome";
  const optAsym = document.getElementById("agOptAsym")?.checked;
  const optLed = document.getElementById("agOptLed")?.checked;
  const optWings = document.getElementById("agOptWings")?.checked;
  const optCorset = document.getElementById("agOptCorset")?.checked;
  const customWish = (document.getElementById("agCustomWishInput")?.value || "").trim();

  // Anthropometric calculations (cm) based on height & weight
  const bmi = +(weight / ((height / 100) * (height / 100))).toFixed(1);
  const bust = Math.round(74 + (weight - 45) * 0.85 + (height - 160) * 0.12);
  const waist = Math.round(58 + (weight - 45) * 0.78);
  const hips = Math.round(84 + (weight - 45) * 0.92 + (height - 160) * 0.14);
  const frontBodiceLen = +(height * 0.255).toFixed(1);
  const backBodiceLen = +(height * 0.238).toFixed(1);
  const frontWidth = +(bust * 0.49).toFixed(1);
  const backWidth = +(bust * 0.46).toFixed(1);
  const sleeveLen = +(height * 0.355).toFixed(1);
  const armholeCirc = +(34 + (weight - 45) * 0.25).toFixed(1);

  const skirtFrontLen = optAsym ? Math.round(height * 0.51) : Math.round(height * 0.62);
  const skirtSideLen = Math.round(skirtFrontLen + (optAsym ? 26 : 6));
  const skirtBackTrain = Math.round(skirtFrontLen + (optAsym ? 52 : 18));
  const asymDiff = skirtBackTrain - skirtFrontLen;

  // Fabric consumption (meters) scaled to height & size
  const sizeFactor = (height / 168) * (0.85 + (bust / 90) * 0.18);
  const organzaMeters = +(2.6 * sizeFactor + (optWings ? 0.7 : 0)).toFixed(2);
  const metallicMeters = +(1.25 * sizeFactor + (optCorset ? 0.35 : 0)).toFixed(2);
  const crinolineMeters = +(3.4 * sizeFactor).toFixed(1);
  const liningMeters = +(1.4 * sizeFactor).toFixed(2);

  // Face shape futuristic neckline & accessory mapping
  const faceMap = {
    oval: {
      uzName: "Oval",
      collar: "Yelkadan havoga ko'tarilib turuvchi 3D haykaltarosh 'Halo' yoqa va nozik assimetrik kesim",
      enCollar: "floating 3D sculptural halo collar framing an oval face",
      accessory: "Magnit effektli suzuvchi metallik sirg'alar"
    },
    dumaloq: {
      uzName: "Dumaloq",
      collar: "Chuqur V-simon kinetik kesimli yoqa va vertikal yorug'lik chiziqlari (yuzni vizual cho'zadi)",
      enCollar: "sharp deep V-cut kinetic neckline elongating a soft round face",
      accessory: "Uzun vertikal billur-xrom sirg'alar"
    },
    kvadrat: {
      uzName: "Kvadrat",
      collar: "To'lqinsimon suzuvchi organza 'Cowl' yoqasi (jag' chizig'ini mayinlashtiradi)",
      enCollar: "fluid wave-draped translucent organza neckline softening a structured square jawline",
      accessory: "Suyuq simob shaklidagi egri marvarid sirg'alar"
    },
    yuraksimon: {
      uzName: "Yuraksimon",
      collar: "Yelkasi ochiq (Off-Shoulder) antigravitatsion kamon-yoqa (pastki proporsiyani muvozanatlaydi)",
      enCollar: "wide off-shoulder anti-gravity architectural bow collar balancing a heart-shaped face",
      accessory: "Tomchi shaklidagi golografik marjon va sirg'alar"
    },
    uzunchoq: {
      uzName: "Uzunchoq",
      collar: "Gorizontal kengaytirilgan 'Qayiqcha' (Boat-neck) metallik yoqa va 3D yelka qanotlari",
      enCollar: "horizontal sculptural boat-neck chrome collar with wide shoulder arcs balancing an elongated face",
      accessory: "Keng geometrik golografik choker"
    },
    romb: {
      uzName: "Romb / Olmos",
      collar: "Yumshoq yuraksimon (Sweetheart) korset chizig'i va yelkadan uchib turuvchi tumanli shifon qatlami",
      enCollar: "sculpted sweetheart bodice with airy floating chiffon shoulder veil accentuating diamond cheekbones",
      accessory: "Minimalistik yulduzsimon quloq manjetlari (ear cuffs)"
    }
  };
  const faceInfo = faceMap[faceShape] || faceMap.oval;

  // Color palette & studio preset mapping
  const paletteMap = {
    metallic_chrome: {
      uzTitle: "Suyuq Xrom & Kumush Antigravitatsiya",
      hex: "#cfd6dc",
      matId: "mat_silver_sequin",
      dressId: "dress_asym",
      enPalette: "liquid chrome silver, mirror-finish titanium accents, and translucent frost-white silk organza",
      visualEffect: "Yorug'likni ko'zgu kabi qaytarib, harakat paytida vaznsiz suyuq metall va muz kristallari illyuziyasini beradi."
    },
    cosmic_nebula: {
      uzTitle: "Koinot Tumanligi & Yulduzli Oltin",
      hex: "#3a2d44",
      matId: "mat_midnight_stardust",
      dressId: "dress_ballgown",
      enPalette: "deep cosmic indigo, iridescent nebula violet, midnight velvet, and shimmering stardust gold filaments",
      visualEffect: "Chuqur kosmik binafsha va yulduzli oltin tolalar siluetni ingichka va cheksiz chuqurlikka ega qilib ko'rsatadi."
    },
    minimal_white_silver: {
      uzTitle: "Minimalistik Oq-Kumush & Billur Muz",
      hex: "#e6ecf2",
      matId: "mat_crystal_mesh",
      dressId: "dress_notebook_iceblue",
      enPalette: "pure architectural alabaster white, micro-crystal silver mesh, and weightless ice-mist tulle",
      visualEffect: "Mutlaq soflik va yuqori texnologik minimalizm — ko'ylak havoda muallaq turgan bulutdek taassurot qoldiradi."
    },
    neon_cyber: {
      uzTitle: "Neon Kiber-Chiroq & Qora Baxmal",
      hex: "#1c1829",
      matId: "mat_midnight_stardust",
      dressId: "dress_mermaid",
      enPalette: "obsidian cyber-black neoprene with electric cyan and magenta fiber-optic neon edge glow",
      visualEffect: "To'q fon ustidagi elektr neon konturlari tana proporsiyalarini lazer aniqligida chizib beradi."
    },
    holographic_pearl: {
      uzTitle: "Golografik Marvarid & Pushti Opal",
      hex: "#e09ca8",
      matId: "mat_rose_glitter",
      dressId: "dress_ruffle",
      enPalette: "iridescent holographic pearl, liquid rose-gold shimmer, and opalescent pastel organza",
      visualEffect: "Har bir burchakda marvarid va kamalak jilosini taratib, yuz terisiga tabiiy yorqinlik beradi."
    },
    emerald_gold: {
      uzTitle: "Futuristik Zumrad & Suyuq Oltin",
      hex: "#1d5952",
      matId: "mat_emerald_lame",
      dressId: "dress_emerald",
      enPalette: "luminous emerald metallic lamé, sculpted liquid gold ribbing, and sheer jade organza",
      visualEffect: "Qirollik zumrad va suyuq oltin uyg'unligi podiumda hashamatli va futuristik hukmronlik hissini yaratadi."
    }
  };
  const pal = paletteMap[paletteKey] || paletteMap.metallic_chrome;

  const specialFeaturesUz = [
    optAsym ? "asimmetrik havoda muallaq turuvchi organza qatlamlari" : null,
    optLed ? "choklar bo'ylab yashirilgan mikro-LED optik tolali yorug'lik" : null,
    optWings ? "yelkadan suzib turuvchi shaffof 3D aerodinamik qanotlar" : null,
    optCorset ? "qomatni qolipdek ushlab turuvchi 3D haykaltarosh kinetik korset" : null,
    customWish ? customWish : null
  ].filter(Boolean);

  const specialFeaturesEn = [
    optAsym ? "weightless asymmetric floating silk organza tiers suspended in mid-air" : "",
    optLed ? "delicate embedded warm-white fiber-optic micro-LED light seams glowing subtly along the sculptural edges" : "",
    optWings ? "translucent architectural 3D aerodynamic organza shoulder wings defying gravity" : "",
    optCorset ? "precision-molded 3D kinetic couture corset bodice with metallic boning" : "",
    customWish ? `custom couture detail: ${customWish}` : ""
  ].filter(Boolean).join(", ");

  const buildDescEn = bmi < 19.5 ? "slender elongated" : bmi <= 24.5 ? "graceful balanced hourglass" : "sculpted curvaceous";
  const photoRefPrompt = agUserPhotoDataUrl ? "matching the facial features, complexion, and likeness of the uploaded user portrait, " : "";

  const englishPrompt = `Haute couture futuristic "Anti-Gravity" evening gown editorial fashion photography, full-length shot of a ${height}cm tall ${buildDescEn} woman, ${photoRefPrompt}${faceInfo.enCollar}, wearing a breathtaking avant-garde dress crafted from ${pal.enPalette}, featuring ${specialFeaturesEn || "levitating translucent silk organza drapes"}. Ultra-fine fabric physics showing iridescent light refraction, microscopic shimmer, crisp laser-cut edges, and floating movement. Dramatic low-angle editorial fashion camera (85mm f/1.8 lens, Vogue Italia & Iris van Herpen haute couture aesthetic), volumetric rim lighting, soft studio mist, futuristic minimalist architectural glass atelier background with subtle zero-gravity floating light dust, hyper-realistic skin texture, 8k resolution, photorealistic, --ar 2:3 --v 6.0 --style raw`;

  agLastGeneratedConfig = {
    title: `Anti-Gravity: ${pal.uzTitle}`,
    color: pal.hex,
    matId: pal.matId,
    dressId: pal.dressId
  };

  if (!silent) {
    state.stars += 30;
    state.score += 1800;
    unlockBadge("ai_explorer");
    renderTopStats();
  }

  outEl.innerHTML = `
    <!-- TOP SUMMARY BANNER WITH OPTIONAL UPLOADED USER PHOTO -->
    <div style="background:linear-gradient(135deg, #16141d 0%, #262134 100%); color:#fff; padding:20px 24px; border:1px solid #3a324f; display:flex; align-items:center; justify-content:space-between; gap:18px; flex-wrap:wrap;">
      <div style="display:flex; align-items:center; gap:16px;">
        ${agUserPhotoDataUrl ? `
          <img src="${agUserPhotoDataUrl}" alt="Model" style="width:74px; height:94px; object-fit:cover; border:2px solid #e6c675; border-radius:4px;" />
        ` : `
          <div style="width:62px; height:62px; border-radius:50%; background:rgba(230,198,117,0.14); border:1.5px solid #e6c675; display:flex; align-items:center; justify-content:center; font-size:24px; color:#e6c675;">✦</div>
        `}
        <div>
          <div style="font-size:10.5px; letter-spacing:2px; text-transform:uppercase; color:#e6c675; font-weight:700;">
            Shaxsiy Anti-Gravity Loyiha • ${height} sm / ${weight} kg (BMI: ${bmi})
          </div>
          <h3 style="font-family:var(--font-serif); font-size:26px; font-weight:600; margin:4px 0;">
            ${pal.uzTitle}
          </h3>
          <div style="font-size:12.5px; color:#d2cddc;">
            Yuz tuzilishi: <strong>${faceInfo.uzName}</strong> • Aksessuar: ${faceInfo.accessory}
          </div>
        </div>
      </div>
      <button class="btn-editorial-light" style="padding:10px 18px; font-size:12px;" onclick="applyAntiGravityToStudio()">
        Studiyada Manekenga Kiyintirish →
      </button>
    </div>

    <!-- 1. FUTURISTIK DIZAYN KONSEPSIYASI -->
    <div style="background:#fff; border:1px solid var(--border); padding:20px 22px;">
      <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:var(--gold); margin-bottom:6px;">
        1-Bo'lim • Konsepsiya
      </div>
      <h4 style="font-family:var(--font-serif); font-size:22px; margin-bottom:10px;">
        Futuristik Dizayn Konsepsiyasi ("Anti-Gravity" Yondashuvi)
      </h4>
      <p style="font-size:13.5px; color:var(--ink-secondary); line-height:1.68; margin-bottom:10px;">
        <strong>Proporsiya va Siluet Tahlili:</strong> Sizning <strong>${height} sm</strong> bo'yingiz va <strong>${weight} kg</strong> vazningiz (ko'krak <strong>${bust} sm</strong> / bel <strong>${waist} sm</strong> / bo'ksa <strong>${hips} sm</strong>) uchun antigravitatsion konstruksiya "Oltin Nisbat" tamoyilida loyihalandi. ${specialFeaturesUz.join(", ")} yordamida ko'ylak tanaga og'irlik qilmaydi, balki bel chizig'ini optik jihatdan ingichkalashtirib, qomatni yanada uzun va vaznsiz ko'rsatadi.
      </p>
      <p style="font-size:13.5px; color:var(--ink-secondary); line-height:1.68; margin-bottom:10px;">
        <strong>Yuz Tuzilishi va Futuristik Yoqa (${faceInfo.uzName}):</strong> ${faceInfo.collar}. Bu chiziq yuz geometriyasi bilan mukammal uyg'unlashadi va <em>${faceInfo.accessory.toLowerCase()}</em> bilan to'ldiriladi.
      </p>
      <p style="font-size:13.5px; color:var(--ink-secondary); line-height:1.68;">
        <strong>Rang Palitrasi va Vizual Effekt:</strong> ${pal.visualEffect}
      </p>
    </div>

    <!-- 2. AI RASM GENERATSIYASI UCHUN ULTRA-DETALLI PROMPT (ENGLISH) -->
    <div style="background:#faf8f4; border:1px solid #d8c3a5; padding:20px 22px;">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:10px;">
        <div>
          <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:#8c6239;">
            2-Bo'lim • Midjourney / DALL-E 3 Prompt
          </div>
          <h4 style="font-family:var(--font-serif); font-size:22px;">
            AI Rasm Generatsiyasi uchun Ultra-Detalli Prompt (English)
          </h4>
        </div>
        <button class="btn-small-dark" id="copyAgPromptBtn" onclick="copyAgPrompt()">
          Promptni Nusxalash (Copy)
        </button>
      </div>
      <div id="agEnglishPromptText" style="background:#181620; color:#f4efe6; font-family:monospace; font-size:12.5px; line-height:1.65; padding:14px 16px; border-radius:4px; user-select:all;">
        ${englishPrompt}
      </div>
    </div>

    <!-- 3. TEXNIK VA KONSTRUKTORLIK HISOB-KITOBI -->
    <div style="background:#fff; border:1px solid var(--border); padding:20px 22px;">
      <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:var(--gold); margin-bottom:6px;">
        3-Bo'lim • Konstruktorlik Hisob-Kitobi (sm &amp; m)
      </div>
      <h4 style="font-family:var(--font-serif); font-size:22px; margin-bottom:14px;">
        Texnik va Konstruktorlik Hisob-Kitobi (Anti-Gravity Kesimi)
      </h4>

      <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:16px;">
        <div style="background:#faf8f5; border:1px solid var(--border); padding:14px;">
          <div style="font-weight:700; font-size:13px; margin-bottom:8px; color:var(--ink);">Mato Turi va Aniq Sarfi (Metrda):</div>
          <ul style="font-size:13px; color:var(--ink-secondary); line-height:1.8; padding-left:18px; margin:0;">
            <li><strong>Havodor Ipak Organza / Shifon (150 sm enli):</strong> ${organzaMeters} metr</li>
            <li><strong>Metallik Lamé / 3D Neopren (korset &amp; struktura):</strong> ${metallicMeters} metr</li>
            <li><strong>Shaffof Krinolin (Regilin) tasma (uchish effekti uchun):</strong> ${crinolineMeters} metr</li>
            <li><strong>Tabiiy Ipak Astar (ichki qatlam):</strong> ${liningMeters} metr</li>
          </ul>
        </div>

        <div style="background:#faf8f5; border:1px solid var(--border); padding:14px;">
          <div style="font-weight:700; font-size:13px; margin-bottom:8px; color:var(--ink);">Aniq O'lchamlar (Santimetrda):</div>
          <ul style="font-size:13px; color:var(--ink-secondary); line-height:1.8; padding-left:18px; margin:0;">
            <li><strong>Ko'krak / Bel / Son aylanasi:</strong> ${bust} sm / ${waist} sm / ${hips} sm</li>
            <li><strong>Old qism uzunligi × eni:</strong> ${frontBodiceLen} sm × ${frontWidth} sm</li>
            <li><strong>Orqa qism uzunligi × eni:</strong> ${backBodiceLen} sm × ${backWidth} sm</li>
            <li><strong>Asimmetrik qatlam uzunliklari:</strong> Oldi ${skirtFrontLen} sm | Yoni ${skirtSideLen} sm | Orqa shleyf ${skirtBackTrain} sm (farqi: +${asymDiff} sm)</li>
            <li><strong>Yeng uzunligi / Yeng o'mizi aylanasi:</strong> ${sleeveLen} sm / ${armholeCirc} sm</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- 4. BOSQICHMA-BOSQICH FUTURISTIK TIKISH QO'LLANMASI -->
    <div style="background:#fff; border:1px solid var(--border); padding:20px 22px;">
      <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:var(--gold); margin-bottom:6px;">
        4-Bo'lim • Atelier Master-Klass
      </div>
      <h4 style="font-family:var(--font-serif); font-size:22px; margin-bottom:12px;">
        Bosqichma-Bosqich Futuristik Tikish Qo'llanmasi
      </h4>
      <ol style="font-size:13.5px; color:var(--ink-secondary); line-height:1.75; padding-left:20px; margin:0; display:flex; flex-direction:column; gap:8px;">
        <li><strong>Lazerli / Termik Bichish:</strong> ${organzaMeters} m havodor organza va ${metallicMeters} m metallik matoni 45° qiyalikda (bias cut) lazerli kesgich yoki termik pichoqda biching — bu organza chetlari sitilmasligini va tolalar yengil ko'tarilib turishini ta'minlaydi.</li>
        <li><strong>Kinetik Korset va Karkas Yig'ish:</strong> Old (${frontBodiceLen} sm) va orqa (${backBodiceLen} sm) korset detallariga 8 ta egiluvchan spiral regilin suyakchalari (boning) o'rnating. Bel qismini aniq ${waist} sm o'lchamda qolipdek mahkamlang.</li>
        <li><strong>Antigravitatsion Qatlamlarni Dreyperovka Qilish:</strong> Asimmetrik etak qatlamlarining (oldi ${skirtFrontLen} sm dan orqa ${skirtBackTrain} sm gacha) pastki chetiga 4 sm kenglikdagi shaffof krinolin tasmasini yashirin chok bilan tiking — aynan shu texnologiya etakni havoda to'lqinsimon suzib turadigan qiladi.</li>
        <li><strong>Futuristik Yoqa Konstruksiyasi:</strong> ${faceInfo.uzName} yuz shakli uchun mo'ljallangan yoqa detalini yupqa shaffof silikon karkas bilan mustahkamlab, yelka chokiga ${armholeCirc} sm yeng o'mizi bo'ylab aniq joylashtiring.</li>
        <li><strong>Yashirin Fransuzcha Choklar va Optik Detallar:</strong> Barcha shaffof qatlam ulanishlarini 3 mm li yashirin fransuzcha chok (French seam) bilan bajaring. ${optLed ? "Korset ichki qatlamiga o'ta yengil mikro-batareya cho'ntagi tikib, optik tolali LED chiziqlarni bel va etak chetiga yashirin mahkamlang." : "Metallik parcha va billur toshlarni qo'lda ko'rinmas monofilament ip bilan qadang."}</li>
        <li><strong>Yakuniy Bug'lash va Muvozanat Tekshiruvi:</strong> Libosni manekenga kiydirib, vertikal bug'lagich (steamer) bilan 15 sm masofadan shakl bering va uchib turuvchi qatlamlarning simmetrik muvozanatini tekshiring.</li>
      </ol>
    </div>
  `;
}

function copyAgPrompt() {
  const txt = document.getElementById("agEnglishPromptText")?.innerText?.trim();
  if (!txt) return;
  navigator.clipboard?.writeText(txt).then(() => {
    const btn = document.getElementById("copyAgPromptBtn");
    if (btn) {
      btn.textContent = "Nusxalandi ✓";
      setTimeout(() => { btn.textContent = "Promptni Nusxalash (Copy)"; }, 2000);
    }
  });
}

function applyAntiGravityToStudio() {
  if (!agLastGeneratedConfig) generateAntiGravityBlueprint(true);
  state.editingPortfolioId = null;
  state.studio.dressName = agLastGeneratedConfig.title;
  state.studio.color = agLastGeneratedConfig.color;
  state.studio.bgStyle = "sketch_wings";
  state.studio.equipped = {
    faces: "face_editorial_5",
    hair: "hair_high_pony",
    materials: agLastGeneratedConfig.matId,
    dresses: agLastGeneratedConfig.dressId,
    tops: null,
    trousers: null,
    bottom_details: null,
    bags: "bag_clutch",
    belt: "belt_diamond",
    shoes: "heels_strappy",
    stickers: null
  };
  renderStudioUI();
  switchView("studio");
}

window.addEventListener("DOMContentLoaded", () => {
  generateAntiGravityBlueprint(true);
});


// ============================================================================
// INTERACTIVE MODA LABORATORIYASI:
// 1. Virtual Mato Fizikasi | 2. Podium 360° & Muhit | 3. Face & Style Sync
// 4. Tikuvchilik Ustaxonasi (Lekalo Mini-O'yini) | 5. Kunlik Chellenj & Lookbook
// ============================================================================
let activeLabTab = "blueprint";
let labSelectedFabricId = "holo_organza";
let runwayEnv = "neon";
let runwaySpinTimer = null;
let dailyChallengeDone = false;

const LAB_FABRICS = [
  { id: "holo_organza", name: "Golografik Organza", color: "#e6ecf2", matId: "mat_crystal_mesh", lightness: 98, durability: 62, eco: 84, sheen: 96, swayMul: 1.35 },
  { id: "silk_chiffon", name: "Shaffof Ipak Shifon", color: "#f5eae2", matId: "mat_notebook_floral", lightness: 95, durability: 58, eco: 92, sheen: 78, swayMul: 1.5 },
  { id: "liquid_chrome", name: "Metallik Suyuq Xrom", color: "#cfd6dc", matId: "mat_silver_sequin", lightness: 72, durability: 94, eco: 70, sheen: 100, swayMul: 0.55 },
  { id: "eco_tencel", name: "Ekologik Tencel Ipak", color: "#b7cde2", matId: "mat_notebook_ice_pleat", lightness: 88, durability: 82, eco: 99, sheen: 74, swayMul: 1.1 },
  { id: "rose_glitter", name: "Pushti Olmos To'r", color: "#e09ca8", matId: "mat_rose_glitter", lightness: 86, durability: 76, eco: 80, sheen: 95, swayMul: 1.0 },
  { id: "neoprene_3d", name: "3D Futuristik Neopren", color: "#1c1829", matId: "mat_midnight_stardust", lightness: 64, durability: 98, eco: 68, sheen: 82, swayMul: 0.35 }
];

function openLabTab(tabName) {
  switchView("antigravity");
  switchLabTab(tabName);
}

function switchLabTab(tabName) {
  activeLabTab = tabName;
  document.querySelectorAll(".lab-subtab-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.lab === tabName);
  });
  document.querySelectorAll(".lab-pane").forEach(pane => pane.classList.remove("active"));
  const target = document.getElementById(`labPane-${tabName}`);
  if (target) target.classList.add("active");

  if (tabName === "fabric") renderFabricLab();
  else if (tabName === "runway") updateRunwayView();
  else if (tabName === "facesync") updateFaceStyleSync();
  else if (tabName === "lekalo") initLekaloBoard();
}

// --- 1. VIRTUAL MATO LABORATORIYASI ---
function renderFabricLab() {
  const listEl = document.getElementById("labFabricList");
  if (!listEl) return;
  listEl.innerHTML = LAB_FABRICS.map(f => `
    <button class="${labSelectedFabricId === f.id ? 'btn-small-dark' : 'btn-small-outline'}"
            style="text-align:left; padding:8px 10px; font-size:11.5px;"
            onclick="selectLabFabric('${f.id}')">
      ${f.name}
    </button>
  `).join("");
  updateFabricPhysicsSim();
}

function selectLabFabric(id) {
  labSelectedFabricId = id;
  renderFabricLab();
}

function updateFabricPhysicsSim() {
  const fab = LAB_FABRICS.find(f => f.id === labSelectedFabricId) || LAB_FABRICS[0];
  const wind = parseInt(document.getElementById("labWindSlider")?.value || "45", 10);
  const light = parseInt(document.getElementById("labLightSlider")?.value || "120", 10);

  const windLbl = document.getElementById("labWindVal");
  const lightLbl = document.getElementById("labLightVal");
  if (windLbl) windLbl.textContent = `${wind}%`;
  if (lightLbl) lightLbl.textContent = `${light}°`;

  const scoresEl = document.getElementById("labFabricScores");
  if (scoresEl) {
    scoresEl.innerHTML = `
      <div style="font-weight:700; font-size:13px; margin-bottom:10px;">${fab.name} — Texnik Ko'rsatkichlari:</div>
      <div style="margin-bottom:8px; font-size:12px;">
        <div style="display:flex; justify-content:space-between;"><span>Yengillik (Antigravitatsiya):</span><strong>${fab.lightness}%</strong></div>
        <div class="lab-stat-bar-bg"><div class="lab-stat-bar-fill" style="width:${fab.lightness}%;"></div></div>
      </div>
      <div style="margin-bottom:8px; font-size:12px;">
        <div style="display:flex; justify-content:space-between;"><span>Chidamlilik:</span><strong>${fab.durability}%</strong></div>
        <div class="lab-stat-bar-bg"><div class="lab-stat-bar-fill" style="width:${fab.durability}%;"></div></div>
      </div>
      <div style="margin-bottom:8px; font-size:12px;">
        <div style="display:flex; justify-content:space-between;"><span>Ekologik tozalik:</span><strong>${fab.eco}%</strong></div>
        <div class="lab-stat-bar-bg"><div class="lab-stat-bar-fill" style="width:${fab.eco}%;"></div></div>
      </div>
      <div style="font-size:12px;">
        <div style="display:flex; justify-content:space-between;"><span>Yorug'lik tovlanishi:</span><strong>${fab.sheen}%</strong></div>
        <div class="lab-stat-bar-bg"><div class="lab-stat-bar-fill" style="width:${fab.sheen}%;"></div></div>
      </div>
    `;
  }

  const swayWrap = document.getElementById("labFabricSwayWrap");
  if (swayWrap) {
    const skewDeg = ((wind / 100) * 9 * fab.swayMul).toFixed(1);
    swayWrap.style.setProperty("--wind-skew", `${skewDeg}deg`);
    swayWrap.style.animationDuration = `${Math.max(0.7, 3.0 - (wind / 50))}s`;
  }

  const sheenOverlay = document.getElementById("labLightSheenOverlay");
  if (sheenOverlay) {
    sheenOverlay.style.background = `linear-gradient(${light}deg, transparent 20%, rgba(255,255,255,${(fab.sheen / 180).toFixed(2)}) 48%, rgba(215,190,255,0.28) 56%, transparent 80%)`;
  }

  const svgEl = document.getElementById("labFabricSvg");
  if (svgEl) {
    svgEl.innerHTML = generateFashionSvg({
      mannequinId: state.activeMannequinId,
      color: fab.color,
      hairColor: state.studio.hairColor,
      bgStyle: "atelier_clean",
      equipped: {
        ...state.studio.equipped,
        materials: fab.matId,
        dresses: state.studio.equipped.dresses || "dress_notebook_yellow"
      }
    }, true);
  }
}

function applyLabFabricToStudio() {
  const fab = LAB_FABRICS.find(f => f.id === labSelectedFabricId) || LAB_FABRICS[0];
  state.studio.color = fab.color;
  state.studio.equipped.materials = fab.matId;
  if (!state.studio.equipped.dresses) state.studio.equipped.dresses = "dress_notebook_yellow";
  state.stars += 20;
  state.score += 1200;
  renderTopStats();
  renderStudioUI();
  switchView("studio");
}

// --- 2. INTERAKTIV PODIUM VA MUHIT SINOVI (360° & ANTI-GRAVITY) ---
const RUNWAY_ENVS = {
  neon: { label: "Kechki Neon Shahar", bg: "radial-gradient(circle at 50% 25%, #3b1c5a 0%, #120d26 65%, #070512 100%)", floor: "rgba(0, 240, 255, 0.25)" },
  space: { label: "Kosmik Stansiya", bg: "radial-gradient(circle at 50% 20%, #1d2f4f 0%, #0b1021 70%, #020308 100%)", floor: "rgba(245, 223, 152, 0.22)" },
  garden: { label: "Bahorgi Bog'", bg: "linear-gradient(180deg, #dceef5 0%, #eaf2e3 60%, #d4e3c5 100%)", floor: "rgba(125, 168, 108, 0.25)" },
  carpet: { label: "Rasmiy Qizil Gilam", bg: "radial-gradient(circle at 50% 15%, #5c1a24 0%, #2b0910 68%, #140307 100%)", floor: "rgba(220, 175, 85, 0.35)" }
};

function setRunwayEnv(envKey) {
  runwayEnv = envKey;
  ["neon", "space", "garden", "carpet"].forEach(k => {
    const b = document.getElementById(`envBtn_${k}`);
    if (b) b.className = k === envKey ? "btn-small-dark" : "btn-small-outline";
  });
  updateRunwayView();
}

function updateRunwayView() {
  const env = RUNWAY_ENVS[runwayEnv] || RUNWAY_ENVS.neon;
  const agOn = document.getElementById("runwayAgToggle")?.checked;
  const angle = parseInt(document.getElementById("runwayAngleSlider")?.value || "0", 10);

  const angleVal = document.getElementById("runwayAngleVal");
  if (angleVal) angleVal.textContent = `${angle}°`;

  const stageBox = document.getElementById("runwayStageBox");
  if (stageBox) stageBox.style.background = env.bg;

  const badge = document.getElementById("runwayEnvBadge");
  if (badge) badge.textContent = `${env.label} • ${agOn ? "0.0G Anti-Gravity" : "1.0G Oddiy Gravitatsiya"} • ${angle}°`;

  const model3d = document.getElementById("runwayModel3d");
  if (model3d) {
    model3d.classList.toggle("ag-floating-active", !!agOn);
    model3d.style.transform = `rotateY(${angle}deg)`;
  }

  const svgEl = document.getElementById("runwayStageSvg");
  if (svgEl) {
    svgEl.innerHTML = generateFashionSvg({
      mannequinId: state.activeMannequinId,
      color: state.studio.color,
      hairColor: state.studio.hairColor,
      bgStyle: "atelier_clean",
      equipped: {
        ...state.studio.equipped,
        dresses: state.studio.equipped.dresses || "dress_notebook_yellow"
      }
    }, true);
  }
}

function toggleRunwayAutoSpin() {
  const btn = document.getElementById("runwayAutoSpinBtn");
  if (runwaySpinTimer) {
    clearInterval(runwaySpinTimer);
    runwaySpinTimer = null;
    if (btn) btn.textContent = "▶ 360° Avto-Aylantirish";
    return;
  }
  if (btn) btn.textContent = "⏸ To'xtatish";
  runwaySpinTimer = setInterval(() => {
    const slider = document.getElementById("runwayAngleSlider");
    if (!slider) return;
    slider.value = (parseInt(slider.value, 10) + 6) % 360;
    updateRunwayView();
  }, 60);
}

function completeRunwayTest() {
  state.stars += 35;
  state.score += 2100;
  unlockBadge("podium_regular");
  renderTopStats();
  alert("Ajoyib! Podium va 360° muhit sinovi muvaffaqiyatli yakunlandi (+35 Yulduz va +2,100 Ball)!");
}

// --- 3. AQLLI AKSESSUARLAR VA YUZ KONSTRUKTORI (FACE & STYLE SYNC) ---
let currentFaceSyncPreset = null;

function updateFaceStyleSync() {
  const face = document.getElementById("fsFaceShape")?.value || "kvadrat";
  const eye = document.getElementById("fsEyeStyle")?.value || "cat_eye";

  const syncRules = {
    kvadrat: {
      dress: "dress_offshoulder",
      hair: "hair_long_waves",
      color: "#b7cde2",
      mat: "mat_crystal_mesh",
      belt: "belt_pearl_chain",
      text: "<strong>Kvadrat yuz</strong> uchun keskin jag' chizig'ini mayinlashtiruvchi <em>yumshoq yelkasi ochiq (Off-Shoulder)</em> yoqa va yuz atrofini yumshatuvchi <em>uzun to'lqinli soch turmagi</em> avtomatik tanlandi."
    },
    oval: {
      dress: "dress_asym",
      hair: "hair_high_pony",
      color: "#cfd6dc",
      mat: "mat_silver_sequin",
      belt: "belt_diamond",
      text: "<strong>Oval yuz</strong> muvozanatli bo'lgani uchun <em>asimmetrik futuristik bir yelkalli ko'ylak</em>, <em>baland silliq ponytail</em> va billur kamar tavsiya etildi."
    },
    dumaloq: {
      dress: "dress_notebook_yellow",
      hair: "hair_sleek_part",
      color: "#d4af37",
      mat: "mat_liquid_gold",
      belt: "belt_gold",
      text: "<strong>Dumaloq yuz</strong>ni optik cho'zish uchun chuqur <em>V-yoqali ko'ylak</em>, <em>o'rtadan ochilgan tekis uzun soch</em> va oltin vertikal aksessuarlar moslashtirildi."
    },
    yuraksimon: {
      dress: "dress_ballgown",
      hair: "hair_parisian_bob",
      color: "#e09ca8",
      mat: "mat_rose_glitter",
      belt: "belt_ribbon",
      text: "<strong>Yuraksimon yuz</strong>da nozik iyakni muvozanatlash uchun <em>keng etakli malika silueti</em> va <em>Parijcha bob soch turmagi</em> uyg'unlashtirildi."
    },
    uzunchoq: {
      dress: "dress_ruffle",
      hair: "hair_side_sweep",
      color: "#1d5952",
      mat: "mat_emerald_lame",
      belt: "belt_corset_wide",
      text: "<strong>Uzunchoq yuz</strong>ga gorizontal muvozanat berish uchun <em>qat-qat ruffle hajmli ko'ylak</em> va <em>yon tomonga taralgan hajmli soch</em> tanlandi."
    }
  };

  const eyeMap = {
    cat_eye: { faceId: "face_editorial_7", desc: "Mushuk ko'z strelka va baland qosh" },
    soft_almond: { faceId: "face_editorial_1", desc: "Bodomsimon tabiiy editorial nigoh" },
    smokey_glam: { faceId: "face_editorial_3", desc: "Qizil lab va podium nigohi" },
    futuristic_glasses: { faceId: "face_editorial_8", desc: "Futuristik qora-oltin podium ko'zoynagi" }
  };

  const rule = syncRules[face] || syncRules.kvadrat;
  const eyeInfo = eyeMap[eye] || eyeMap.cat_eye;

  currentFaceSyncPreset = {
    color: rule.color,
    equipped: {
      faces: eyeInfo.faceId,
      hair: rule.hair,
      materials: rule.mat,
      dresses: rule.dress,
      belt: rule.belt,
      bags: "bag_clutch",
      shoes: "heels_strappy"
    }
  };

  const box = document.getElementById("fsRecommendationBox");
  if (box) {
    box.innerHTML = `
      ${rule.text}
      <div style="margin-top:8px; padding-top:8px; border-top:1px dashed #d8c3a5;">
        <strong>Ko'z &amp; Aksessuar Sync:</strong> ${eyeInfo.desc} + libos rangiga mos klatch sumka va kamar.
      </div>
    `;
  }

  const svgEl = document.getElementById("fsPreviewSvg");
  if (svgEl) {
    svgEl.innerHTML = generateFashionSvg({
      mannequinId: state.activeMannequinId,
      color: rule.color,
      hairColor: state.studio.hairColor,
      bgStyle: "notebook_2024",
      equipped: currentFaceSyncPreset.equipped
    }, true);
  }
}

function applyFaceStyleSyncToStudio() {
  if (!currentFaceSyncPreset) updateFaceStyleSync();
  state.studio.color = currentFaceSyncPreset.color;
  state.studio.equipped = {
    ...state.studio.equipped,
    ...currentFaceSyncPreset.equipped
  };
  state.stars += 25;
  state.score += 1500;
  renderTopStats();
  renderStudioUI();
  switchView("studio");
}

// --- 4. "TIKUVCHILIK USTAXONASI" MINI-O'YINI (INTERAKTIV LEKALO & KALKULYATOR) ---
let lekaloPieces = [];

function resetLekaloGame() {
  lekaloPieces = [
    { id: "p_front", label: "Old qism", x: 16, y: 16, w: 96, h: 112 },
    { id: "p_back", label: "Orqa qism", x: 132, y: 16, w: 92, h: 108 },
    { id: "p_skirt1", label: "Etak (Oldi)", x: 244, y: 16, w: 128, h: 152 },
    { id: "p_skirt2", label: "Etak (Orqa)", x: 16, y: 154, w: 134, h: 156 },
    { id: "p_sleeves", label: "Yenglar (x2)", x: 174, y: 186, w: 108, h: 86 },
    { id: "p_collar", label: "3D Yoqa", x: 392, y: 192, w: 86, h: 58 }
  ];
  renderLekaloBoard();
}

function initLekaloBoard() {
  if (!lekaloPieces.length) resetLekaloGame();
  else renderLekaloBoard();
}

function renderLekaloBoard() {
  const board = document.getElementById("lekaloBoard");
  if (!board) return;

  board.innerHTML = lekaloPieces.map((p, idx) => `
    <div class="lekalo-piece" data-idx="${idx}"
         style="left:${p.x}px; top:${p.y}px; width:${p.w}px; height:${p.h}px;"
         ondblclick="rotateLekaloPiece(${idx})"
         onmousedown="startDragLekalo(event, ${idx})">
      <span>${p.label}</span>
      <span style="font-size:9px; opacity:0.75;">${p.w}×${p.h}</span>
    </div>
  `).join("");

  recalcLekaloStats();
}

function rotateLekaloPiece(idx) {
  const p = lekaloPieces[idx];
  const board = document.getElementById("lekaloBoard");
  if (!p || !board) return;
  const tmp = p.w;
  p.w = p.h;
  p.h = tmp;
  p.x = Math.min(p.x, Math.max(0, board.clientWidth - p.w));
  p.y = Math.min(p.y, Math.max(0, board.clientHeight - p.h));
  renderLekaloBoard();
}

function startDragLekalo(e, idx) {
  e.preventDefault();
  const board = document.getElementById("lekaloBoard");
  const p = lekaloPieces[idx];
  if (!board || !p) return;

  const startX = e.clientX - p.x;
  const startY = e.clientY - p.y;

  function onMove(ev) {
    const maxW = board.clientWidth - p.w;
    const maxH = board.clientHeight - p.h;
    p.x = Math.max(0, Math.min(maxW, ev.clientX - startX));
    p.y = Math.max(0, Math.min(maxH, ev.clientY - startY));
    const el = board.querySelector(`.lekalo-piece[data-idx="${idx}"]`);
    if (el) {
      el.style.left = `${p.x}px`;
      el.style.top = `${p.y}px`;
    }
    recalcLekaloStats();
  }

  function onUp() {
    window.removeEventListener("mousemove", onMove);
    window.removeEventListener("mouseup", onUp);
  }

  window.addEventListener("mousemove", onMove);
  window.addEventListener("mouseup", onUp);
}

function recalcLekaloStats() {
  const board = document.getElementById("lekaloBoard");
  const statsBox = document.getElementById("lekaloStatsBox");
  if (!board || !statsBox) return { overlapCount: 0, meters: 2.4, wastePct: 35 };

  let overlapCount = 0;
  let maxRight = 0;
  let totalPieceArea = 0;
  const els = board.querySelectorAll(".lekalo-piece");
  els.forEach(el => el.classList.remove("overlap-err"));

  for (let i = 0; i < lekaloPieces.length; i++) {
    const a = lekaloPieces[i];
    totalPieceArea += a.w * a.h;
    if (a.x + a.w > maxRight) maxRight = a.x + a.w;
    for (let j = i + 1; j < lekaloPieces.length; j++) {
      const b = lekaloPieces[j];
      if (a.x < b.x + b.w - 2 && a.x + a.w - 2 > b.x && a.y < b.y + b.h - 2 && a.y + a.h - 2 > b.y) {
        overlapCount++;
        if (els[i]) els[i].classList.add("overlap-err");
        if (els[j]) els[j].classList.add("overlap-err");
      }
    }
  }

  const usedStripArea = Math.max(1, maxRight * board.clientHeight);
  const efficiency = Math.min(96, Math.round((totalPieceArea / usedStripArea) * 100));
  const wastePct = Math.max(4, 100 - efficiency);
  const metersUsed = +(Math.max(1.4, (maxRight / 215))).toFixed(2);
  const costUsd = Math.round(metersUsed * 24 + 38);
  const sewHours = +(4.5 + metersUsed * 1.3).toFixed(1);

  statsBox.innerHTML = `
    <div><strong>Ustma-ust tushish xatosi:</strong> <span style="color:${overlapCount ? '#b02a37' : '#155724'}; font-weight:700;">${overlapCount === 0 ? "Yo'q (Mukammal ✓)" : overlapCount + " ta andoza ustma-ust!"}</span></div>
    <div><strong>Mato samaradorligi:</strong> <strong style="color:var(--ink);">${efficiency}%</strong></div>
    <div><strong>Chiqindi (qiyqindi) mato:</strong> <strong style="color:${wastePct <= 28 ? '#155724' : '#8c6239'};">${wastePct}%</strong></div>
    <hr style="border:none; border-top:1px solid var(--border); margin:8px 0;" />
    <div><strong>Aniq mato sarfi:</strong> <strong>${metersUsed} metr</strong> (150 sm enli)</div>
    <div><strong>Taxminiy tannarx:</strong> <strong>$${costUsd}</strong> (~${(costUsd * 12800).toLocaleString()} so'm)</div>
    <div><strong>Tikish vaqti:</strong> <strong>${sewHours} soat</strong></div>
  `;

  return { overlapCount, metersUsed, wastePct, efficiency };
}

function submitLekaloMiniGame() {
  const res = recalcLekaloStats();
  if (res.overlapCount > 0) {
    alert("Qizil rangdagi andozalar ustma-ust tushib qolgan! Ularni ajrating va qayta tekshiring.");
    return;
  }
  const bonusStars = res.wastePct <= 25 ? 80 : res.wastePct <= 35 ? 55 : 35;
  state.stars += bonusStars;
  state.score += bonusStars * 60;
  unlockBadge("style_master");
  renderTopStats();
  alert(`Ofarin! Mato samaradorligi ${res.efficiency}% (chiqindi bor-yo'g'i ${res.wastePct}%, sarf: ${res.metersUsed} m). Sizga +${bonusStars} Yulduz bonus berildi!`);
}

// --- 5. KUNLIK CHELLENJ VA SHAXSIY LOOKBOOK ULASHISH ---
function checkDailyChallenge() {
  if (dailyChallengeDone) {
    alert("Bugungi kunlik chellenjni allaqachon muvaffaqiyatli bajargansiz!");
    return;
  }
  const h = parseFloat(document.getElementById("agHeightInput")?.value || "168");
  const face = document.getElementById("agFaceShapeInput")?.value || "oval";
  const res = recalcLekaloStats();

  if (Math.abs(h - 165) <= 5 && face === "oval" && res.metersUsed <= 2.2) {
    dailyChallengeDone = true;
    state.stars += 100;
    state.score += 5000;
    unlockBadge("challenge_champion");
    renderTopStats();
    const btn = document.getElementById("dailyChallengeBtn");
    if (btn) btn.textContent = "Bajarildi (+100 Yulduz ✓)";
    alert("TABRIKLAYMIZ! Kunlik Moda Chellenjini mukammal bajardingiz (+100 Yulduz va +5,000 Ball)!");
  } else {
    alert("Chellenj sharti: Anti-Gravity bo'limida bo'yni 165 sm, yuzni 'Oval' tanlang va Lekalo ustaxonasida andozalarni ixcham joylab mato sarfini 2.2 metrdan kamaytiring!");
  }
}

function sharePersonalLookbook() {
  const count = Math.min(10, state.portfolio.length);
  const titles = state.portfolio.slice(0, 10).map((p, i) => `${i + 1}. ${p.title} (${p.color})`).join("\n");
  const shareText = `FASHION QUEEN — ${state.playerName} Shaxsiy Lookbook (${count}/10):\n${titles || "Yangi kolleksiya tayyorlanmoqda!"}`;
  navigator.clipboard?.writeText(shareText).then(() => {
    const btn = document.getElementById("shareLookbookBtn");
    if (btn) {
      btn.textContent = "Lookbook Nusxalandi ✓";
      setTimeout(() => { btn.textContent = "Lookbookni Ulashish (Copy)"; }, 2200);
    }
  });
}
